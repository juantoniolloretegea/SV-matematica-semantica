---
article:
  elocation-id: autogobierno-topologico-y-comunicacion-estructural-de-observables-en-el-universo-fisico-realizado
author:
- Juan Antonio Lloret Egea
bibliography: /tmp/tmp-20o70BXHZ4sC4x.json
copyright:
  link: "https://creativecommons.org/licenses/by-nc-nd/4.0/"
  text: Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
    International License
  type: CC-BY-NC-ND
csl: /app/dist/server/server/utils/citations/citeStyles/apa-7th-edition.csl
date:
  day: 30
  month: 05
  year: 2026
journal:
  publisher-name: IA eñ ™ - (La Biblia de la IA - The Bible of AI ™ ISSN
    2695-6411)
  title: IA eñ ™
link-citations: true
title: Autogobierno topológico y comunicación estructural de observables
  en el Universo físico realizado
uri: "https://www.itvia.online/pub/autogobierno-topologico-y-comunicacion-estructural-de-observables-en-el-universo-fisico-realizado"
---

![](https://assets.pubpub.org/c39829d0b-6cf2-4c57-8562-04aa66068f1d/p8431307a-6a10-4f56-ae49-3baac47ed327/u8d2bc69d-73c6-4669-a7e7-fb07fdba4171/portada-01780156174069.png){#ndr7v5ix8b1}

------------------------------------------------------------------------

**© 2026. Todos los derechos reservados.** \| [**Juan Antonio Lloret
Egea**](https://www.linkedin.com/in/juanantoniolloretegea/ "null") \|
**DOI** \[pendiente\] \| **ORCID:**
[0000-0002-6634-3351](https://orcid.org/0000-0002-6634-3351 "null") \|
[Instituto Tecnológico Virtual de la Inteligencia Artificial para el
Español™ (ITVIA)](https://www.itvia.online/ "null") \| IA eñ™ --- La
Biblia de la IA™ \| [**ISSN
2695-6411**](https://portal.issn.org/resource/ISSN/2695-6411 "null") \|
**Licencia CC BY-NC-ND 4.0** \| Madrid, 28/05/2026 \| [**Repositorio
canónico**](https://github.com/juantoniolloretegea/SV-matematica-semantica/tree/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables "null")

------------------------------------------------------------------------

## **Resumen**

Se formula el autogobierno topológico y la comunicación estructural de
observables en el Universo físico realizado. Parte del resultado ya
establecido en [*Potencial de un suceso: comunicación estructural en el
Universo físico realizado, equipotencialidad, diferencia polar y
métrica*](https://doi.org/10.21428/39829d0b.f0cbabc2 "null"); el
potencial local del suceso, su diferencia entre sucesos, su métrica
tipada, su transducción por dominios y su comunicación estructural
quedaron fijados como plano local y comparativo. Desde esta base, la
formulación asciende al plano de los observables y del dominio realizado
como conjunto. El comparador con realimentación formaliza el
autogobierno topológico mediante los polos `(0,1)` de la terna factual
`(0,1,U)`, la equipotencialidad inicial `(0,0)` bajo la identidad TODO =
NADA, la ruptura por imperfección preformal `ε−0`, la convergencia
asintótica gobernada y la conservación de `U` como indeterminación
honesta. La ejecución operativa entre observables se formula mediante la
ley general del tránsito por dominios
`T_D^SV(D_i,D_j;x)=0 ⇔ R_D^SV(D_i,D_j;x)=0`, el teorema de identidad de
tránsito `Id_trans^SV`, la fórmula universal de gobierno de observables
`𝓒★ObsU(x,D)∈{0,1,U}`, la familia derivada de transductores `𝓖★TrU(D)` y
la consolidación de canal, diccionario semántico estructural, residual y
retorno mediante `Diag_AB^⊥`. El desarrollo distingue de forma estricta
el potencial local `P_D(e)` del suceso y la magnitud global `Φ(τ)` del
comparador: comparten estructura polar, pero pertenecen a planos
distintos. La coherencia operativa de los observables como conjunto no
se presenta como transmisión física al unísono, sintiencia, agencia ni
propósito, sino como propiedad topológica del lazo realimentado bajo
imperfección sostenida. La formulación conserva las prohibiciones
constitutivas del SV: sin tiempo rector, sin probabilidad fundante, sin
inferencia opaca, sin cierre favorable por ausencia de prueba y sin
degradación de `U` a ruido, media o ignorancia.

------------------------------------------------------------------------

## ***Abstract***

*This work formulates the topological self-government and structural
communication of observables in the realised physical Universe. It
proceeds from the result already established in* [Potencial de un
suceso: comunicación estructural en el Universo físico realizado,
equipotencialidad, diferencia polar y
métrica](https://doi.org/10.21428/39829d0b.f0cbabc2 "null"), *where the
local potential of the event, the potential difference between events,
typed metrics, domain transduction and structural communication were
fixed as the local and comparative plane. From that ground, the
formulation rises to the plane of observables and of the realised domain
as a whole. The closed-loop comparator formalises topological
self-government through the poles* `(0,1)` *of the factual triad*
`(0,1,U)`*, the initial equipotential state* `(0,0)` *under the identity
ALL = NOTHING, rupture by preformal imperfection* `ε−0`*, governed
asymptotic convergence and the preservation of* `U` *as honest
indeterminacy. The operational execution between observables is
formulated through the general law of domain transit*
`T_D^SV(D_i,D_j;x)=0 ⇔ R_D^SV(D_i,D_j;x)=0`*, the transit identity
theorem* `Id_trans^SV`*, the universal formula of observable governance*
`𝓒★ObsU(x,D)∈{0,1,U}`*, the derived family of transducers* `𝓖★TrU(D)`*,
and the consolidation of channel, structural semantic dictionary,
residual and return through* `Diag_AB^⊥`\*. *The publication strictly
distinguishes the local potential* `P_D(e)` *of the event from the
global magnitude* `Φ(τ)` *of the comparator: they share polar structure,
but they belong to different planes. The operational coherence of
observables as a whole is not presented as physical unison transmission,
sentience, agency or purpose, but as a topological property of the
closed loop under sustained imperfection. The formulation preserves the
constitutive prohibitions of the SV: no governing time, no foundational
probability, no opaque inference, no favourable closure by absence of
proof, and no degradation of* `U` *into noise, average or ignorance.*

------------------------------------------------------------------------

## **Índice** {#ndice}

-   **0. Continuidad formal con Potencial de un suceso**

-   **I. Fundamentos y principio rector**

-   **II. Imperfección preformal y fibra primigenia de observabilidad**

-   **III. Estado del arte y errores de plano**

-   **IV. Comparador con realimentación**

-   **V. Convergencia asintótica gobernada**

-   **VI. Régimen ciclo-distancial y topología sin transmisión**

-   **VII. Predominancia compatible y predominancia lesiva**

-   **VIII. Autogobierno sin agencia**

-   **IX. Ley general del tránsito por dominios**

-   **X. Fórmula universal de gobierno de observables**

-   **XI. Transductores, canal, diccionario semántico estructural y
    consolidación**

-   **XII. Relación entre potencial local, comparador global y
    observables**

-   **XIII. Matriz de correspondencia formal**

-   **XIV. Alcance declarado y condiciones de refutación**

-   **XV. Laboratorios**

-   **XVI. Conclusión**

-   **Anexo I --- Bibliografía y referencias del corpus**

------------------------------------------------------------------------

## **0. Continuidad formal con Potencial de un suceso**

### **0.1. Del potencial del suceso al gobierno de observables**

Se presupone como antecedente inmediato *Potencial de un suceso:
comunicación estructural en el Universo físico realizado,
equipotencialidad, diferencia polar y métrica* (Lloret Egea, 2026a).
Allí quedó fijado el plano local del suceso: potencial
`P_D(e)=μ_D(e)−λ_D(e)`, intensidad `I_D(e)=μ_D(e)+λ_D(e)`, origen formal
`(0,0)`, equilibrio realizado `(a,a)` con `a>0`, diferencia de potencial
entre sucesos, residual de admisibilidad, métrica tipada, transducción
por dominios y comunicación estructural entre sucesos. Ese resultado no
se repite como fundamento nuevo: se toma como base operativa cerrada
para elevar la lectura hacia el gobierno de observables y hacia el
dominio realizado como conjunto. La continuidad no convierte al
observable en suceso ni al suceso en observable. El suceso es
reevaluación estructural admisible dentro de un horizonte declarado; el
observable es contenido gobernable en un dominio bajo magnitudes,
frontera, identidad, canal, barrera, residual, retorno y traza. La
transición entre ambos planos exige control formal: no basta que un
observable participe en un suceso, ni que un suceso produzca una traza
observable. La relación queda mediada por dominio, transducción y
residual.

### **0.2. Distinción entre **`P_D(e)`** y **`Φ(τ)` {#distincin-entre-pde-y}

La forma polar aparece en dos planos distintos. En el plano local del
suceso, el potencial se expresa como `P_D(e)=μ_D(e)−λ_D(e)`, con
intensidad asociada `I_D(e)=μ_D(e)+λ_D(e)`. En el plano global del
comparador, la magnitud de desequilibrio se expresa como
`Φ(τ)=Φ_polo_0(τ)−Φ_polo_1(τ)`. La homología formal no autoriza
identidad de objeto: `P_D(e)` mide separación polar de un suceso
admisible en un dominio declarado; `Φ(τ)` mide el desequilibrio
estructural del comparador con realimentación en el dominio realizado.
Esta distinción impide dos errores de plano. El primero sería leer el
comparador global como si fuera un suceso local ampliado. El segundo
sería leer el potencial local como si contuviera por sí solo la
topología del dominio realizado. La relación correcta es de continuidad
formal y subordinación de planos: el potencial local ofrece el régimen
de lectura polar del suceso; el comparador global usa una magnitud polar
propia para formalizar la dinámica topológica del dominio realizado bajo
`ε−0`, con conservación de `U` como indeterminación honesta.

### **0.3. Comunicación entre sucesos y comunicación entre observables** {#comunicacin-entre-sucesos-y-comunicacin-entre-observables}

La comunicación estructural entre sucesos quedó formulada en el plano de
`P_D(e)`, `ΔP_D(e_i,e_j)`, canal, traza, residual y retorno. La
comunicación estructural entre observables exige un paso adicional: los
observables pertenecen a familias, dominios y transductores que pueden
no coincidir con los sucesos que los hacen visibles. Por ello, la
comunicación entre observables se gobierna por `T_D^SV`, `Id_trans^SV`,
`𝓒★ObsU`, `𝓖★TrU(D)` y `Diag_AB^⊥`. El término «comunicación
estructural» conserva el mismo blindaje semántico en ambos planos. No
designa diálogo sintiente, intención, voluntad ni transmisión física al
unísono. Designa consolidación formal de canal, diccionario, residual,
traza y retorno. En el plano de los sucesos, esa consolidación recae
sobre diferencias de potencial y trayectorias; en el plano de los
observables, recae sobre tránsito por dominios, admisión de observable
fuerte, transducción tipada y retorno estructural.

## **I. Fundamentos y principio rector** {#i-fundamentos-y-principio-rector}

### **I.1. Plano físico-formal del Universo realizado** {#i1-plano-fsico-formal-del-universo-realizado}

El Universo físico realizado constituye el dominio sobre el que opera el
SV. No es abstracción matemática autónoma, no es simulación, no es
modelo desconectado del régimen material. Es el dominio en el que
comparecen observables tipados, observables no tipados, dominios
conocidos y dominios desconocidos. La formulación opera en plano
físico-formal: estudia la estructura formal del dominio realizado en
cuanto propiedad operativa del dominio mismo, no en cuanto entidad
ontológica externa que lo gobernara desde fuera. El plano físico-formal
se separa con rigor de dos planos vecinos. Del plano puramente
físico-empírico se distingue porque no se reduce a la cuantificación
experimental de observables; del plano puramente lógico-formal se
distingue porque no opera sobre proposiciones abstractas sino sobre
observables del dominio realizado bajo restricciones constitutivas
declaradas. La aportación se sitúa en la conjunción operativa de
estructura formal y dominio realizado, sin disolver la una en el otro.

### **I.2. Subordinación de la estructura matemática al cierre rector** {#i2-subordinacin-de-la-estructura-matemtica-al-cierre-rector}

La estructura matemática que describe el Universo físico realizado no lo
funda como instancia exterior. Codifica y decodifica su funcionamiento,
comparece después de la primera distinguibilidad y queda subordinada al
cierre rector. La distinción es decisiva, porque evita simultáneamente
dos errores opuestos. El primer error consistiría en afirmar
equivalencia ontológica fuerte entre realidad física y estructura
matemática, identificando ambas sin restricción, según la línea
tegmarkiana en su forma máxima (Tegmark, 2008). Este desarrollo no asume
esa equivalencia. El segundo error consistiría en negar estructura
formal al dominio físico, tratándola como construcción humana
superpuesta sin propiedad operativa intrínseca. Tampoco acepta esa
negación. La posición sostenida es estable: la estructura matemática es
propiedad formal del dominio mismo, no separada de él ni adicional a él,
y opera bajo subordinación al cierre rector. Las matemáticas no preceden
al dominio realizado; comparecen como su codificación y decodificación
tras la primera distinguibilidad.

### **I.3. Deslinde de planos teológicos, espiritualistas y panpsiquistas** {#i3-deslinde-de-planos-teolgicos-espiritualistas-y-panpsiquistas}

La tesis no afirma sintiencia distribuida del Universo. No afirma
intencionalidad cósmica, propósito, diseño, agencia universal,
consciencia integrada ni alma del mundo. La coherencia operativa de los
observables como conjunto es propiedad formal de la estructura, no
testimonio de agencia. El uso técnico del término «comunicación
estructural» refiere a la consolidación formal de canal, diccionario
semántico estructural y retorno entre observables de familias distintas,
bajo el aparato formal declarado. No refiere a diálogo en sentido
sintiente. No implica receptor consciente. No presupone emisor con
intención. El uso técnico del término «autogobierno» refiere a propiedad
topológica del lazo realimentado bajo imperfección sostenida. No implica
voluntad. No implica propósito. No implica observador interno del
dominio. **La tendencia del sistema al reequilibrio es propiedad de la
dinámica del lazo, en el mismo sentido en que la tendencia al máximo de
entropía es propiedad de un sistema termodinámico cerrado: gradiente
estructural, no propósito**. Toda lectura panpsiquista, espiritualista o
teológica queda fuera del alcance de la formulación por decisión formal
explícita.

### **I.4. Principio rector** {#i4-principio-rector}

El principio rector queda enunciado en términos directos: el Universo
físico realizado sostiene la coherencia operativa de todos sus
observables como conjunto bajo dos propiedades articuladas. La primera
es topología del lazo realimentado entre los polos `(0, 1)` de la terna
factual bajo identidad entrada-salida regida por TODO = NADA, con
ruptura simétrica espontánea por imperfección preformal `ε−0` y
convergencia asintótica gobernada con `U` preservada como
indeterminación honesta cuando no procede cierre binario. La segunda es
ejecución operativa del lazo entre observables mediante canal
estructural, diccionario semántico estructural, residual gobernado y
retorno trazado. Ningún observable fuerte admitido en el dominio
realizado queda fuera de estas dos propiedades sin residual explícito.
La coherencia es propiedad estructural del dominio realizado; no es
contenido material que viaje ni manifestación de intención. Se formaliza
esta arquitectura como una secuencia única: primero se establece el
suelo de fundamentos y observabilidad; después se desarrolla el
comparador con realimentación, la convergencia gobernada y el régimen
ciclo-distancial; finalmente se articulan tránsito por dominios,
gobierno de observables, transductores, canal, diccionario, matriz de
correspondencia, laboratorios y conclusión.

------------------------------------------------------------------------

## **II. Imperfección preformal y fibra primigenia de observabilidad** {#ii-imperfeccin-preformal-y-fibra-primigenia-de-observabilidad}

### **II.1. ε−0 como borde preformal** {#ii1-0-como-borde-preformal}

`ε−0` nombra el borde de imperfección anterior a la primera
distinguibilidad. No es objeto físico, no es instante cosmológico, no es
campo, no es partícula, no es vacío cuántico, no es magnitud energética,
no es función de onda, no es contenido medible dentro del Universo
observable. Su condición es preformal: no comparece como observable
fuerte y, precisamente por eso, hace posible que pueda haber
distinguibilidad y, consecuentemente, que pueda abrirse después el
dominio de los observables. La función de `ε−0` consiste en impedir
tanto la clausura indiferenciada como la aparición gratuita de lo
observable. **Sin imperfección preformal no hay diferencia; sin
diferencia no hay frontera; sin frontera no hay dominio; sin dominio no
hay observable; sin observable no hay ciencia externa ni transducción**.
La cadena fundamental queda fijada como: `ε−0 ⊢ ∂ε ⊢ Dsep ⊢ Ωesp`; `ε−0`
abre la primera posibilidad de distinguibilidad, `∂ε` expresa el borde
de separación, `Dsep` constituye dominio de separación y `Ωesp` habilita
el espacio como dominio estructural de separación factual recorrible.
Esta cadena no es física constituida; prepara el sustrato sobre el que
podrán aparecer magnitudes, señales, cuerpos, moléculas, células,
organismos, documentos y trazas (Lloret Egea, 2026b).

### **II.2. La fibra primigenia de observabilidad como restricción funcional** {#ii2-la-fibra-primigenia-de-observabilidad-como-restriccin-funcional}

La fibra primigenia de observabilidad no constituye una segunda raíz
junto a `ε−0`. Su formulación correcta es funcional:
`𝓕−0^Obs = ε−0|Obs`. La igualdad no afirma que toda primera
distinguibilidad sea ya observable pleno. Afirma que la posibilidad de
observabilidad solo puede nacer como restricción funcional del borde
preformal de imperfección. Si `𝓕−0^Obs` se separara de `ε−0`, habría que
distinguir dos fundamentos antes de que la distinguibilidad estuviera
disponible, lo cual introduce circularidad. Si `𝓕−0^Obs` se confundiera
sin restricción con `ε−0`, toda apertura preformal quedaría convertida
indebidamente en dominio observable completo. La solución estable es
identidad de origen y diferencia de función: `ε−0` abre la primera
distinguibilidad; `𝓕−0^Obs` expresa la orientación observacional de esa
apertura. La fibra primigenia no produce por sí misma galaxias, virus,
cánceres, organismos, especies, planetas o documentos. Lo que produce es
el cimiento formal para que algo pueda llegar a ser observable bajo
dominio. Entre `𝓕−0^Obs` y cualquier observable fuerte intervienen
separación, dominio, fórmula universal, transductor, magnitud, frontera,
identidad, canal, barrera, residual, retorno y traza.

### **II.3. Cadena de determinación de la observabilidad** {#ii3-cadena-de-determinacin-de-la-observabilidad}

La observabilidad no nace de golpe, sino por una secuencia de
determinación. Desde `𝓕−0^Obs` emerge `∂Obs` como borde de
observabilidad; desde `∂Obs` se constituye `DObs` como dominio formal de
observabilidad; desde `DObs` se habilita `ObsU(D)`, clase de contenidos
que pueden aspirar a observable fuerte en un dominio `D`. La secuencia
completa queda así: `ε−0|Obs ⊢ ∂Obs ⊢ DObs ⊢ ObsU(D)`. `∂Obs` separa lo
que puede entrar en régimen de observación de lo que aún carece de
dominio. `DObs` impide que el observable sea etiqueta vacía: obliga a
que el candidato esté dotado de las condiciones necesarias para ser
observable bajo algún dominio. `ObsU(D)` exige a todo candidato `x`
quedar ligado a un dominio, una magnitud, una frontera, una identidad,
un canal, una barrera, un residual, un retorno y una traza. La
diferencia entre `DObs` y un dominio sectorial es decisiva. `DObs` no es
astrofísica, no es química, no es biología, no es medicina, no es
evolución, no es documento: es el dominio formal en el que puede
hablarse de observables. Cada ciencia o dominio sectorial se abre
después mediante su transductor especializado. Esta arquitectura evita
dos errores simétricos: declarar observable lo que no tiene dominio, y
negar observabilidad a lo que aún no cierra plenamente pero conserva
posibilidad honesta en `U`.

### **II.4. Teorema de identidad funcional restringida** {#ii4-teorema-de-identidad-funcional-restringida}

**Teorema.** `𝓕−0^Obs` no constituye un segundo principio distinto de
`ε−0`, sino la restricción observacional de `ε−0`; y todo observable
fuerte presupone esa restricción, aunque no se reduzca a ella.
**Demostración.** Todo observable fuerte `x ∈ ObsU(D)` exige
distinguibilidad, porque debe separarse de lo que no es `x`. Toda
distinguibilidad presupone `ε−0` como borde preformal de imperfección.
Por tanto, todo observable presupone `ε−0`. Ahora bien, `ε−0` en sentido
absoluto no equivale a observable constituido, porque antes de dominio,
frontera, transducción y retorno no hay objeto observable. Debe existir,
por tanto, una función restringida que conserve el origen preformal y
habilite el tránsito hacia observabilidad. Esa función es
`𝓕−0^Obs = ε−0|Obs`. Si se niega la restricción, se identifica
indebidamente preformalidad con observabilidad plena; si se separa la
restricción del origen, se duplica el fundamento. Ambas alternativas
fallan. (C.Q.D.). La consecuencia formal es estricta: `ε−0` es condición
preformal de toda observabilidad; `𝓕−0^Obs` es la fibra primigenia de
observabilidad; sobre esa fibra operan los dos niveles formales que
articulan el resto de la formulación.

------------------------------------------------------------------------

## **III. Estado del arte y errores de plano** {#iii-estado-del-arte-y-errores-de-plano}

### **III.1. Realimentación, termodinámica y ruptura de simetría** {#iii1-realimentacin-termodinmica-y-ruptura-de-simetra}

La cuestión del autogobierno estructural del Universo físico tiene
tratamiento parcial en varias direcciones de la literatura
contemporánea. La segunda ley de la termodinámica, formulada por
Clausius (1879) y refinada por Boltzmann (1872), establece la tendencia
al máximo de entropía en sistemas cerrados, sin requerir agencia. La
cibernética de Wiener (1948) formaliza la realimentación como propiedad
topológica de sistemas autorregulados, también sin agencia. La
termodinámica de sistemas disipativos de Prigogine (Prigogine y
Stengers, 1984; Nicolis y Prigogine, 1989) muestra que la complejidad
creciente y el orden local pueden emerger como propiedades de sistemas
alejados del equilibrio que disipan gradientes. La ruptura espontánea de
simetría, central en la física del modelo estándar y formalizada en el
mecanismo de Higgs (Higgs, 1964; Englert y Brout, 1964), ofrece el
antecedente formal de cómo una configuración inicialmente simétrica
puede dar lugar a una configuración asimétrica sin intervención
exterior. La cosmología cíclica conforme de Penrose (2010) aporta un
antecedente externo sobre lectura cíclica, aunque no constituye el
núcleo aquí.

### **III.2. Información, canales y estructura matemática** {#iii2-informacin-canales-y-estructura-matemtica}

La comunicación entre observables distintos tiene antecedentes en la
teoría de la información de Shannon (1948), la teoría cuántica de la
información (Holevo, 1998; Nielsen y Chuang, 2000), la conjetura ER =
EPR de Maldacena y Susskind (2013) y el principio holográfico (\'t
Hooft, 1993; Susskind, 1995; Bekenstein, 1973). La fundamentación lógica
del aparato trivalente se remonta a Łukasiewicz (1920) y Kleene (1938),
con aplicaciones posteriores en bases de datos relacionales con valores
nulos (Codd, 1979). En filosofía de las matemáticas, la hipótesis del
Universo matemático de Tegmark (2008), la discusión sobre la efectividad
de las matemáticas (Wigner, 1960; Hamming, 1980) y el estructuralismo
matemático (Hellman, 1989; Shapiro, 1997; Resnik, 1997) sitúan el
problema de la estructura formal sin resolverlo en el plano SV.

### **III.3. Errores de plano que deben bloquearse** {#iii3-errores-de-plano-que-deben-bloquearse}

El primer error consiste en convertir la realimentación topológica en
voluntad, propósito o agencia. El segundo consiste en convertir la
comunicación estructural en lenguaje sintiente, diálogo consciente o
emisión intencional. El tercero consiste en leer `T_obs` o `τ` como
tiempo rector, cuando la formulación los utiliza como régimen y
parámetro ciclo-distanciales. El cuarto consiste en transferir sin
control los resultados de la teoría de la información, la teoría
cuántica de canales, la holografía o el estructuralismo matemático al
SV. El quinto consiste en reducir `U` a incertidumbre estadística, ruido
eliminable, valor intermedio o ignorancia provisional. Estos errores
destruirían la tesis, porque sustituirían dominio, frontera, residual,
retorno y traza por analogías externas.

### **III.4. Posición del Sistema Vectorial SV** {#iii4-posicin-del-sistema-vectorial-sv}

La formulación dialoga con esas tradiciones sin reducirse a ninguna. El
comparador con realimentación, la imperfección preformal `ε−0`, la terna
`(0,1,U)`, la ley general del tránsito por dominios, la fórmula
universal de gobierno de observables y la familia derivada de
transductores pertenecen al SV. Los formalismos contemporáneos citados
ofrecen contraste, antecedentes parciales y lenguaje comparativo, pero
no constituyen la base aquí. La estructura matemática comparece tras la
primera distinguibilidad y queda subordinada al cierre rector; no funda
el dominio realizado como instancia exterior ni autoriza equivalencia
ontológica fuerte.

## **IV. Comparador con realimentación** {#iv-comparador-con-realimentacin}

### **IV.0. Definiciones operativas del comparador** {#iv0-definiciones-operativas-del-comparador}

`Φ_polo_0(τ)` designa la magnitud formal asociada al polo cero del
comparador en el parámetro ciclo-distancial `τ`. `Φ_polo_1(τ)` designa
la magnitud formal asociada al polo uno. `Φ(τ)=Φ_polo_0(τ)−Φ_polo_1(τ)`
designa el desequilibrio estructural del comparador con realimentación,
no el potencial local de un suceso. `τ` es parámetro ciclo-distancial de
lectura del lazo; no es tiempo rector, duración rectora ni cronología
externa. `γ` designa coeficiente de relajación estructural del lazo; no
es constante física universal ni parámetro empírico importado. `ξ(ε−0)`
designa la fuente formal de imperfección sostenida procedente del borde
preformal `ε−0`; no es ruido estadístico ni fluctuación probabilística.
`Φ_∞` designa el régimen asintótico de imperfección gobernada, con
`Φ_∞≠0` mientras `ξ(ε−0)` permanezca sostenida. `T_obs` designa el
régimen ciclo-distancial formalizado por el [Teorema de resolución
física de la constante
cosmológica](https://www.itvia.online/pub/campo-y-energia-genesis-de-la-masa-y-definicion-fisica-de-la-gravedad-gravitacion-universal-constante-cosmologica-y-dominio-observable#anexos "null");
su uso aquí no introduce tiempo rector ni profecía física sobre el
cierre del ciclo. Estas definiciones fijan la diferencia entre el
comparador global y el potencial local del suceso. La notación polar
común no autoriza identidad de objeto. El comparador gobierna el dominio
realizado como conjunto; el potencial local mide separación polar de
sucesos admisibles bajo dominio declarado.

### **IV.1. Equipotencialidad inicial bajo TODO = NADA** {#iv1-equipotencialidad-inicial-bajo-todo-nada}

El dominio realizado, antes de la primera distinguibilidad, se describe
formalmente como configuración de equipotencialidad entre los polos
`(0, 1)` de la terna factual. La equipotencialidad inicial queda fijada
como: `Φ_0 = Φ_polo_0 − Φ_polo_1 = 0`. `Φ_polo_i` es la magnitud formal
de potencial estructural del polo `i`. La equipotencialidad `(0, 0)` no
es estado físico medible; es configuración formal preformal bajo
identidad TODO = NADA, en línea con la *Teoría del TODO y de la NADA en
el Sistema Vectorial SV* (Lloret Egea, 2026f). Bajo la identidad TODO =
NADA, entrada y salida del sistema no son nodos topológicos distintos:
son el mismo nodo bajo doble papel funcional. Esa identidad es la
condición topológica que habilita la realimentación sin canal externo:
la salida del lazo es la entrada del lazo, sin trayecto intermedio.

### **IV.2. Ruptura simétrica espontánea por imperfección preformal** {#iv2-ruptura-simtrica-espontnea-por-imperfeccin-preformal}

La imperfección preformal `ε−0` rompe la equipotencialidad inicial. La
ruptura no procede de agente externo, no procede de fluctuación cuántica
del vacío (que es ya régimen físico constituido), no procede de causa
eficiente anterior. Procede de la propiedad estructural del borde
preformal de imperfección: `ε−0` no admite clausura indiferenciada y,
por tanto, fuerza la aparición de diferencia. La formulación es análoga
a ruptura espontánea de simetría en la teoría de campos, con la
diferencia operativa de que aquí la simetría rota es la
equipotencialidad preformal entre polos, no la simetría de un campo
cuántico ya constituido. La ruptura asigna referencia a uno de los polos
y variabilidad al otro: `Φ(τ_0) = Φ_polo_0 − Φ_polo_1 ≠ 0` tras la
ruptura*.* La asignación de cuál polo queda como referencia y cuál como
variable es contingente respecto del aparato: exige que haya asimetría
tras la ruptura, no qué polo ocupa cada función. La dinámica
subsiguiente es independiente de esa asignación.

### **IV.3. Identidad entrada-salida y lazo de retorno** {#iv3-identidad-entrada-salida-y-lazo-de-retorno}

Bajo TODO = NADA, la salida del comparador no se proyecta a un nodo
externo: vuelve al sistema como entrada. La estructura formal del lazo
queda: `Φ_entrada(τ) = Φ_salida(τ−Δτ)` con identidad bajo* TODO = NADA.*
`Δτ` representa el desfase ciclo-distancial estructural del lazo. La
identidad entre entrada y salida no implica simultaneidad propagativa:
implica que la trayectoria de la salida no abandona el sistema. El lazo
está cerrado topológicamente. No hay nodo exterior. No hay canal físico
que transmita la realimentación; la realimentación es propiedad
topológica del dominio realizado bajo la identidad fundamental del TODO
con la NADA.

### **IV.4. Formulación topológica del lazo** {#iv4-formulacin-topolgica-del-lazo}

La dinámica del lazo bajo realimentación queda formalizada como
gradiente estructural, sin lenguaje propositivo:
`dΦ/dτ = −γ · Φ + ξ(ε−0)`; `γ` es coeficiente de relajación estructural,
`τ` es parámetro ciclo-distancial, y `ξ(ε−0)` es fuente formal de
imperfección sostenida procedente del borde de imperfección. El término
`−γ · Φ` representa la relajación inducida por el lazo; el término
`ξ(ε−0)` representa la fuente formal de imperfección que `ε−0` sostiene
de manera permanente. La dinámica es la de un oscilador amortiguado con
fuente sostenida, no la de un sistema con objetivo. La configuración del
lazo conduce asintóticamente a `Φ → 0` en ausencia de `ξ(ε−0)`; con
`ξ(ε−0)` persistente, `Φ` se mantiene en imperfección gobernada sin
alcanzar el reposo absoluto. La formulación no afirma que el sistema
«quiera» equilibrarse, «busque» reposo o «se proponga» nada. Afirma que
la geometría del lazo bajo gradiente y la presencia de esa fuente formal
de imperfección sostenida producen el régimen dinámico descrito. **Es
topología, no propósito**.

------------------------------------------------------------------------

## **V. Convergencia asintótica gobernada** {#v-convergencia-asinttica-gobernada}

### **V.1. Por qué el sistema no clausura al reposo absoluto** {#v1-por-qu-el-sistema-no-clausura-al-reposo-absoluto}

La dinámica del lazo, en ausencia de `ξ(ε−0)`, llevaría a `Φ → 0` cuando
`τ → ∞`. Ese sería el estado de clausura absoluta: `Φ = 0` significa
equipotencialidad recobrada, ausencia de diferencia entre polos, retorno
a la NADA. En ese estado, no habría observables, no habría dominio
realizado, no habría Universo físico. La existencia sostenida del
dominio realizado exige que la clausura absoluta no se alcance. La
condición estructural que impide la clausura es la persistencia de
`ξ(ε−0)`. Si `ε−0` se anulara, el lazo cerraría y el dominio realizado
terminaría. Como `ε−0` es borde preformal estructural ---condición sin
la cual no habría dominio en absoluto---, su persistencia es condición
previa de todo el sistema, no es una hipótesis *ad hoc*. La formulación
queda fijada como: `lim_{τ→∞} Φ(τ) = Φ_∞ ≠ 0` *bajo* `ξ(ε−0)`
*sostenida.* El sistema converge asintóticamente a un estado de
imperfección gobernada `Φ_∞`, no al reposo absoluto. La convergencia es
asintótica, no efectiva. La existencia de `Φ_∞ ≠ 0` es lo que sostiene
la persistencia del dominio realizado.

### **V.2. Imperfección sostenida como condición de la existencia realizada** {#v2-imperfeccin-sostenida-como-condicin-de-la-existencia-realizada}

La imperfección sostenida no es defecto: es condición de su existencia
realizada. Un sistema sin imperfección sostenida clausuraría al reposo y
no habría dominio en el que comparezcan observables. La imperfección
sostenida es lo que mantiene el lazo activo y, con él, la posibilidad de
los observables. Esta lectura difiere de cualquier interpretación de la
imperfección como ruido eliminable, error a corregir o estado epistémico
provisional. La imperfección preformal es estructural, no contingente.
No puede eliminarse sin disolver el dominio realizado en su totalidad.

### **V.3. U como estado terminal legítimo** {#v3-u-como-estado-terminal-legtimo}

La indeterminación honesta `U` queda formalizada como estado terminal
legítimo del aparato. La diferencia respecto a sistemas binarios es
operativa, no terminológica: en un sistema binario `(0, 1)`, todo estado
debe resolverse en `0` o `1`; cualquier configuración intermedia se
trata como ruido, error o provisionalidad. En el SV, `U` es estado de
pleno derecho asociado al no cierre que introduce la imperfección
preformal, no susceptible de reducción a `0` o `1` sin pérdida de
información estructural. La presencia de `U` no causa el proceso ni
actúa como motor del lazo: expresa que la clausura binaria no queda
autorizada cuando subsiste no determinación estructural. Si todos los
estados se resolvieran en `0` o `1`, el lazo quedaría descrito como
convergencia al reposo absoluto. Con `U` como estado terminal legítimo,
el sistema conserva una clase no vacía de configuraciones que no son ni
equipotencialidad recobrada ni diferencia plenamente resuelta. Esa clase
señala la no clausura del régimen, sin sustituir a `ε−0` ni a la
topología del lazo. La formulación queda: el conjunto de estados
terminales es `{0, 1, U}`, y `U` no es residual transitorio sino estado
de pleno derecho. La hipótesis del «*it from bit*» (Wheeler, 1990) queda
articulada desde el SV con la adición estructural de `U`, lo que
constituye diferencia operativa, no renombramiento.

------------------------------------------------------------------------

## **VI. Régimen ciclo-distancial y topología sin transmisión** {#vi-rgimen-ciclo-distancial-y-topologa-sin-transmisin}

### **VI.1. T_obs como horizonte estructural** {#vi1-tobs-como-horizonte-estructural}

El régimen ciclo-distancial `T_obs` queda formalizado en el *Teorema de
resolución física de la constante cosmológica del Sistema Vectorial SV*
(Lloret Egea, 2026h). El valor canónico es:
`T_obs ≈ 4,354948800 × 10¹⁷ s`. La expresión en segundos pertenece al
retorno metrológico externo del régimen ciclo-distancial; no convierte
el parámetro en tiempo rector ni en duración soberana. `T_obs` no es
duración temporal rectora ni edad cosmológica en sentido convencional.
Es régimen ciclo-distancial estructural que fija el horizonte de
cualquier comunicación física coherente dentro del Universo físico
realizado bajo régimen propagativo. Toda propagación causal queda
acotada por `c · T_obs` como distancia máxima compatible con coherencia
simultánea propagativa.

### **VI.2. Ciclo completo apertura-cierre** {#vi2-ciclo-completo-apertura-cierre}

El ciclo completo del dominio realizado queda formalizado como
`T_obs × 2`. La duplicación tiene fundamento estructural en la geometría
del lazo. La fase de apertura, desde la ruptura simétrica espontánea
hasta la magnitud máxima de `Φ`, requiere un cuarto de ciclo de un
oscilador clásico, o equivalentemente `T_obs` bajo régimen
ciclo-distancial. La fase de relajación asintótica hacia `Φ_∞` requiere
un periodo análogo. El ciclo completo apertura-cierre del dominio
realizado queda del orden de: `T_ciclo ≈ T_obs × 2 ≈ 8,71 × 10¹⁷ s`. El
ciclo completo no constituye reposo absoluto al final: constituye
configuración residual de `Φ_∞` bajo `ξ(ε−0)` sostenida. La duplicación
es geometría del ciclo, no constante arbitraria. El valor exacto del
coeficiente multiplicador puede afinarse formalmente bajo desarrollo
posterior; el orden de magnitud queda fijado por la geometría del lazo.

### **VI.3. Latencia del cambio físico subyacente y propiedad estructural sin transmisión** {#vi3-latencia-del-cambio-fsico-subyacente-y-propiedad-estructural-sin-transmisin}

El cambio físico de un observable opera con la latencia propia de su
régimen material. Una señal electromagnética viaja a velocidad `c`; una
señal mecánica a velocidad del medio; una señal neutrínica a velocidad
cercana a `c` bajo régimen relativista. Ningún sistema físico de
propagación ---electromagnético, mecánico, neutrínico o hipotético
supraluminal--- puede sostener coherencia al unísono extremo a extremo
del dominio bajo el horizonte `T_obs`. La relatividad especial
(Einstein, 1905) fija `c` como límite superior de toda propagación
causal. La hipótesis taquiónica (Bilaniuk et al., 1962; Feinberg, 1967)
carece de evidencia experimental. Las correlaciones a distancia en pares
entrelazados, verificadas en Aspect *et al*. (1982), Hensen *et al*.
(2015) y Giustina *et al*. (2015), no permiten transmisión de
información física utilizable a velocidad superior a `c`, según el
teorema de no-señalización (Ghirardi *et al*., 1980; Eberhard, 1989). La
cosmología relativista sustentada por la colaboración Planck (Planck
Collaboration, 2020) constituye contraste empírico de las magnitudes
citadas. La actualización del lazo realimentado no opera con latencia,
porque no constituye transmisión: constituye propiedad topológica del
dominio mismo bajo TODO = NADA. No hay contenido material que viaje de
un nodo a otro; entrada y salida son el mismo nodo bajo doble papel
funcional. El lazo no requiere propagación porque su topología no es
propagativa. La distinción es operativa, no metafísica. El lazo no es
comunicación al unísono ofuscada bajo nombre distinto: es ausencia de
transmisión. El lazo existe en el dominio porque es propiedad del
dominio, no porque haya llegado a estarlo.

------------------------------------------------------------------------

## **VII. Predominancia compatible y predominancia lesiva** {#vii-predominancia-compatible-y-predominancia-lesiva}

### **VII.1. Configuraciones del lazo bajo captura por un polo** {#vii1-configuraciones-del-lazo-bajo-captura-por-un-polo}

El lazo realimentado admite distintas configuraciones según el régimen
de captura. La configuración base es lazo simétrico bajo realimentación
negativa: el sistema conduce a `Φ_∞ ≠ 0` con ambos polos conservando
función dentro del lazo. Sobre esa configuración base pueden aparecer
regímenes locales donde uno de los polos captura el lazo y altera la
dinámica simétrica. Cuando un polo captura el lazo de manera no
destructiva, el sistema conserva la dinámica asintótica con asimetría
gobernada. Cuando un polo captura el lazo de manera destructiva, el otro
polo pierde función operativa y la dinámica del sub-lazo afectado
colapsa o entra en régimen patológico. La distinción entre los dos
regímenes queda formalizada en los apartados siguientes.

### **VII.2. Régimen compatible** {#vii2-rgimen-compatible}

La predominancia compatible se caracteriza por captura asimétrica del
lazo sin destrucción funcional de los polos. La configuración formal
queda:
`Pred_AB^compat = 1 ⇔ Φ_AB ≠ 0 ∧ R_polo_A trazado ∧ R_polo_B trazado ∧ Δ_AB absorbido`;
`R_polo_i` es retorno operativo del polo `i` dentro del sub-lazo, y
`Δ_AB` es residual de la dinámica asimétrica entre los polos `A` y `B`.
El régimen compatible conserva la operatividad de ambos polos y absorbe
el residual sin transferirlo como daño estructural a niveles superiores.
En astrofísica, la predominancia compatible entre planeta y estrella
sostiene órbita estable, habitabilidad, intercambio energético
gobernado. En biología, la simbiosis metabólica, la inmunidad regulada,
la señalización hormonal coordinada y la microbiota equilibrada con
tejido huésped son configuraciones de predominancia compatible. En
tejido inmunológico, la tolerancia inmune y la respuesta proporcionada
al patógeno son configuraciones compatibles.

### **VII.3. Régimen lesivo** {#vii3-rgimen-lesivo}

La predominancia lesiva se caracteriza por captura del lazo con
destrucción funcional del polo subordinado o transferencia de residual
no absorbido a niveles superiores. La configuración formal queda:
`Pred_AB^lesiva = 1 ⇔ Canal_AB^Γ capturado ∧ 𝓓_AB^⊥ usado contra retorno de Ω_rector ∧ Δ no absorbido`;
`Canal_AB^Γ` es canal estructural del sub-lazo, `𝓓_AB^⊥` es diccionario
semántico estructural entre `A` y `B`, y `Ω_rector` es el dominio rector
cuyo retorno queda comprometido. La predominancia lesiva captura el
canal del sub-lazo, redirige el diccionario contra la coherencia del
dominio rector y deja residual sin absorber. En astrofísica, la acreción
destructiva de una compañera estelar por agujero negro, sin equilibrio
orbital, es predominancia lesiva. En biología, la infección no
controlada, el cáncer con escape inmune, la autoinmunidad crónica, la
sepsis y la toxicidad sistémica son configuraciones lesivas. En tejido
inmunológico, la tormenta de citoquinas y el agotamiento de células T
efectoras son regímenes lesivos del sub-lazo correspondiente. La
distinción entre compatible y lesiva no es valorativa en sentido moral:
es estructural. Predominancia compatible y predominancia lesiva quedan
identificadas por condiciones formales del aparato, no por juicio
externo. El daño es propiedad del sub-lazo bajo captura, no testimonio
de intención del polo capturador.

------------------------------------------------------------------------

## **VIII. Autogobierno sin agencia** {#viii-autogobierno-sin-agencia}

### **VIII.1. La coherencia como propiedad topológica** {#viii1-la-coherencia-como-propiedad-topolgica}

La coherencia operativa del Universo físico realizado como conjunto es
propiedad topológica del lazo bajo `ε−0`. No requiere observador interno
del dominio. No requiere agente que coordine los observables. No
requiere transmisión de información coherente al unísono entre puntos
del dominio. El lazo está cerrado topológicamente por la identidad
entrada-salida bajo TODO = NADA; la dinámica del lazo bajo `ε−0`
sostiene la imperfección gobernada; los dominios locales florecen dentro
de la arquitectura topológica sin requerir coordinación externa. La
formulación es estructural, no propositiva. El sistema no «coordina»
nada; la topología del lazo determina la dinámica global, y los
observables locales operan dentro de la dinámica del lazo según las
restricciones de sus respectivos dominios.

### **VIII.2. Gobernar sin sentir como formulación técnica** {#viii2-gobernar-sin-sentir-como-formulacin-tcnica}

El término técnico «gobernar sin sentir» queda formalizado como
propiedad estructural del lazo realimentado bajo imperfección sostenida.
El término no afirma agencia inconsciente, sustrato semi-sintiente ni
protoconsciencia universal. **Afirma que la dinámica del lazo opera con
autonomía topológica respecto a la presencia o ausencia de observadores
sintientes locales**. La existencia de seres sintientes locales (humanos
en particular) no es condición del lazo. El lazo operaría idéntico con o
sin observadores sintientes. Los seres sintientes son observables de
algunos dominios bajo transductores específicos (`𝔛human`, `𝔛bio` con
régimen complejo), pero su sintiencia es propiedad local del dominio
biológico-humano, no propiedad del lazo global. El lazo no «sabe» que
existen observadores sintientes ni necesita saberlo; opera por
geometría.

### **VIII.3. Deslinde explícito de sintiencia y panpsiquismo** {#viii3-deslinde-explcito-de-sintiencia-y-panpsiquismo}

No se afirma sintiencia distribuida, no afirma protoconsciencia
atribuida a observables no biológicos, no afirma panpsiquismo en ninguna
de sus formas. Las posiciones de Whitehead (1929), Bohm (1980), Smolin
(2013) y Goff (2019) sobre consciencia distribuida quedan situadas en su
plano filosófico-metafísico, sin que la formulación las asuma ni las
rechace en sentido fuerte: la formulación opera en plano físico-formal y
no se pronuncia sobre la naturaleza última de la consciencia. La
aclaración tiene importancia operativa. Una lectura panpsiquista del
comparador con realimentación afirmaría que la propiedad topológica del
lazo es manifestación de una protosintiencia universal. **Esta tesis
rechaza esa lectura explícitamente**: la propiedad topológica del lazo
es estructural, no sintiente, y no se interpreta como manifestación de
algo subyacente más allá de la imperfección preformal `ε−0` y la
identidad TODO = NADA. Aquí no se afirma que el Universo «sienta sin
saberlo» ni que «el lazo sea una forma primitiva de consciencia». El
lazo es geometría. La consciencia local biológica es observable de
dominio específico bajo transductor especializado. Las dos cosas son
distintas y no se reducen una a otra.

------------------------------------------------------------------------

## **IX. Ley general del tránsito por dominios** {#ix-ley-general-del-trnsito-por-dominios}

### **IX.1. Fórmula rectora del tránsito** {#ix1-frmula-rectora-del-trnsito}

La ley general del tránsito por dominios queda formulada bajo el Sistema
Vectorial SV mediante la equivalencia rectora:
`T_D^SV(D_i, D_j; x) = 0 ⇔ R_D^SV(D_i, D_j; x) = 0`; `D_i` y `D_j` son
dominios distinguibles, `x` es candidato a contenido transitivo,
`T_D^SV(D_i, D_j; x)` es la función de tránsito declarada del candidato
`x` entre los dominios `D_i` y `D_j`, y `R_D^SV(D_i, D_j; x)` es el
residual estructural de ese tránsito. El tránsito es legítimo cuando, y
solo cuando, el residual estructural se anula bajo las restricciones
declaradas. La equivalencia rectora se hereda del documento sobre el
régimen H-He ordinario (Lloret Egea, 2026k), en el que queda establecida
como ley general del tránsito por dominios.

### **IX.2. Descomposición del residual en restricciones independientes** {#ix2-descomposicin-del-residual-en-restricciones-independientes}

El residual `R_D^SV` no es escalar opaco. Se descompone en restricciones
independientes, cada una controlando un aspecto estructural del
tránsito:
`R_D^SV(D_i, D_j; x) = ⊕[r_dom, r_id, r_est, r_front, r_canal, r_traza, r_ret]`;
`r_dom` controla pertenencia tipada al dominio de partida y al dominio
de llegada; `r_id` controla identidad declarada del candidato a lo largo
del tránsito; `r_est` controla coherencia del estado declarado bajo
cambio de dominio; `r_front` controla cruce admisible de la frontera
`D_i ↔ D_j`; `r_canal` controla disponibilidad de canal estructural
entre dominios; `r_traza` controla append-only de la huella del
tránsito; `r_ret` controla retorno verificable al dominio de llegada
bajo condiciones declaradas. El operador `⊕` representa la composición
estructural de las restricciones bajo disciplina de residual nulo. La
anulación de `R_D^SV` exige anulación simultánea de todas las
componentes; la persistencia de cualquier componente bloquea el
tránsito. La descomposición es operativamente verificable: cada
componente admite contraste sobre casos concretos del dominio.

### **IX.3. Teorema de identidad de tránsito** {#ix3-teorema-de-identidad-de-trnsito}

El teorema de identidad de tránsito establece la condición necesaria y
suficiente para que una identidad atraviese una cadena finita de
dominios: `Id_trans^SV(x; Γ_D) = 1 ⇔ ⊕_i R_D^SV(D_i, D_{i+1}; x) = 0`;
`Γ_D = (D_0, D_1, …, D_n)` es cadena finita de dominios distinguibles y
`x` es candidato cuya identidad pretende conservarse a lo largo de la
cadena. El teorema demuestra que la continuidad material entre dominios
no se gobierna por igualdad de estados, por analogía, por nombre
compartido ni por importación de teoría externa, sino por identidad de
transición bajo residual controlado.

### **IX.4. Continuidad estructural sin importación de teoría externa** {#ix4-continuidad-estructural-sin-importacin-de-teora-externa}

La aplicación de `T_D^SV — R_D^SV — Id_trans^SV` se ejecuta sobre el
régimen hidrógeno-helio de la materia ordinaria (Lloret Egea, 2026k). La
continuidad de la materia ordinaria queda articulada entre dominio
nuclear, dominio atómico y dominio molecular bajo residual gobernado,
sin importar formalismo externo. La autonomía es deliberada. Los
paralelos contemporáneos ofrecen analogías parciales legítimas, pero no
constituyen el núcleo del residual SV.

------------------------------------------------------------------------

## **X. Fórmula universal de gobierno de observables** {#x-frmula-universal-de-gobierno-de-observables}

### **X.1. Fórmula universal y restricciones constitutivas** {#x1-frmula-universal-y-restricciones-constitutivas}

La fórmula universal de gobierno de observables del Universo físico
realizado queda fijada bajo el SV como:
`𝓒★ObsU(x, D) = 𝓝★[ΩM_D(x), 𝔛_{D↔SV}(x), F_D(x), I_D(x), C_D(x), B_D(x), Δ_D(x), R_D(x), Tr_D(x)] ∈ {0, 1, U}`.
`x` es candidato a observable y `D` es dominio declarable. Las
restricciones constitutivas son: `ΩM_D` declara dominio y magnitudes
externas; `𝔛_{D↔SV}` declara transducción bidireccional entre dominio
externo y aparato SV; `F_D` declara frontera; `I_D` declara identidad;
`C_D` declara canal; `B_D` declara barrera; `Δ_D` declara residual;
`R_D` declara retorno; `Tr_D` declara traza *append-only*. La fórmula no
crea materialmente hidrógeno, galaxia, célula, virus, variante,
enfermedad, cáncer, síntoma, especie, documento o persona. Decide si ese
contenido comparece como observable fuerte. El cierre fuerte queda
formalizado como: `x ∈ ObsU(D) ⇔ 𝓒★ObsU(x, D) = 0`. El valor `1` indica
contradicción material; el valor `U` indica falta de cierre suficiente
sin contradicción, sosteniendo indeterminación honesta. Cualquier
fórmula que omita una restricción falla; cualquier fórmula que las
contenga bajo otros nombres es equivalente; cualquier ampliación solo
aumenta resolución interna. La fórmula universal constituye condición
necesaria y suficiente para la admisibilidad estructural de un
observable en su dominio (Lloret Egea, 2026l).

### **X.2. Familia universal de transductores** {#x2-familia-universal-de-transductores}

La familia de transductores no nace por enumeración local, sino por
derivación directa de `𝓒★ObsU`. Todo transductor legítimo es
especialización de la fórmula universal sobre un dominio `D`, con
selección tipada de magnitudes, frontera, identidad, canal, barrera,
residual, retorno y traza. La forma universal queda fijada como:
`𝓖★TrU(D) = 𝔛_{D↔SV} = (Ω_D, M_D, F_D, I_D, C_D, B_D, Δ_D, R_D, Tr_D)`.
`𝓖★TrU(D)` cumple la función de paso desde la ley universal hacia el
caso de dominio. Primero queda fijada la ley de observabilidad; después
se deriva el transductor que permite leer una señal física, una
molécula, un gen, una célula, una cepa viral, una enfermedad, un tumor,
una especie, un humano singular, un documento, una galaxia o un agujero
negro. La derivación no es opcional. Cualquier transductor introducido
sin pasar por `𝓒★ObsU` queda; cualquier puente nombrado por analogía sin
satisfacer las restricciones constitutivas no constituye transductor
legítimo. La disciplina garantiza coherencia universal bajo
especialización tipada.

### **X.3. Especialización tipada por dominio** {#x3-especializacin-tipada-por-dominio}

Las instancias tipadas de `𝓖★TrU(D)` incluyen, sin agotar la familia,
los transductores `𝔛phys` para magnitudes físicas, `𝔛chem` para química,
`𝔛prebio` para medio prebiológico, `𝔛bio` para biología, `𝔛mut` para
mutación, `𝔛var` para variantes, `𝔛dis` para enfermedad, `𝔛onc` para
cáncer, `𝔛evo` para evolución, `𝔛human` para fibra humana, `𝔛doc` para
documento, `𝔛astr` para astrofísica. Cada instancia se construye
declarando dominio, magnitudes externas, frontera, identidad, canal,
barrera, residual, retorno y traza para ese dominio en particular. La
derivación es operativa y verificable: no se inventan transductores por
analogía; se especializan desde la fórmula universal. Una variante viral
concreta exige `𝔛var(V_i↔SV)`. Un cáncer concreto exige `𝔛onc(Ca_τ↔SV)`.
Una galaxia concreta exige `𝔛astr(Gal_k↔SV)`. La forma universal queda
preservada; la instancia tipada absorbe la singularidad del dominio.

------------------------------------------------------------------------

## **XI. Transductores, canal, diccionario semántico estructural y consolidación** {#xi-transductores-canal-diccionario-semntico-estructural-y-consolidacin}

### **XI.1. Canal estructural entre dominios** {#xi1-canal-estructural-entre-dominios}

La comunicación estructural entre familias distintas de observables
exige canal explícito, no co-presencia ni proximidad. Dos observables de
familias distintas `A` y `B` alcanzan canal estructural `Canal_AB^Γ`
cuando comparecen tres condiciones: interacción física trazable entre
`A` y `B`, frontera operativa que los separa y los relaciona, y receptor
declarado en al menos uno de los dos dominios. Una galaxia y un agujero
negro coexistentes en el mismo campo observacional carecen de canal
consolidado si no hay interacción física trazada (dinámica orbital,
acreción, emisión, lente gravitatoria, perturbación dinámica). Una
célula y un virus coexistentes en el mismo organismo carecen de canal si
no hay entrada, receptor o respuesta declarados. Una bacteria y un
tejido coexistentes en la misma región anatómica carecen de canal si no
hay adhesión, toxina, metabolito o señal reconocible. El canal
estructural no se declara por proximidad ni por simultaneidad: se
declara por trazabilidad de interacción. La regla opera con disciplina
simétrica en todas las familias de observables.

### **XI.2. Diccionario semántico estructural** {#xi2-diccionario-semntico-estructural}

El diccionario semántico estructural asigna correspondencias entre
letras del alfabeto transversal y elementos concretos de dos dominios
`A` y `B`. La estructura formal es:
`𝓓_AB^⊥: 𝔄_⊥ × Ω_A × Ω_B → {correspondencia, corte, U}`. `𝔄_⊥` es
alfabeto transversal de elementos estructurales (frontera, entrada,
receptor, señal, respuesta, daño, reparación, retorno), `Ω_A` y `Ω_B`
son codominios respectivos de `A` y `B`, y el resultado es asignación de
correspondencia legítima, corte explícito o indeterminación honesta `U`.
El diccionario no es tabla de traducción verbal: es matriz de uso.
Declara qué cuenta como frontera, entrada, receptor, señal, respuesta,
daño, reparación y retorno en cada observable. Sin diccionario, el canal
puede existir pero el diálogo estructural queda bloqueado o reducido a
presemántica. Con diccionario parcial, hay protosemántica y respuestas
diferenciadas. Con diccionario cerrado, puede hablarse de diálogo
estructural: el intercambio produce sentido de dominio y retorno
interpretable. El diccionario se construye caso por caso. Para
virus-célula, el receptor puede ser molécula de entrada; la señal puede
ser tropismo; la respuesta puede ser replicación, interferón, apoptosis
o latencia. Para galaxia-agujero negro, el receptor puede ser campo
gravitatorio o disco de acreción; la señal puede ser perturbación
dinámica; la respuesta puede ser chorro, emisión o reordenación
galáctica. Para planeta-estrella, el receptor puede ser campo
gravitatorio o atmósfera; la señal puede ser radiación, viento estelar o
marea; la respuesta puede ser efecto físico ambiental. Para
bacteria-célula, el receptor puede ser adhesina o patrón molecular; la
respuesta puede ser inflamación, fagocitosis o daño tisular.

### **XI.3. Fórmula de consolidación de canal y semántica** {#xi3-frmula-de-consolidacin-de-canal-y-semntica}

La fórmula de consolidación establece cuándo dos observables de familias
distintas alcanzan relación estructural interpretable:
`Diag_AB^⊥ = 1 ⇔ Canal_AB^Γ = 1 ∧ 𝓓_AB^⊥ apto ∧ R_AB trazado ∧ Δ_sem admisible`.
`Canal_AB^Γ` es canal consolidado, `𝓓_AB^⊥ apto` es diccionario cerrado
o suficiente, `R_AB` es retorno trazado entre `A` y `B`, y `Δ_sem` es
residual semántico admisible. La fórmula admite tres estados
principales. Estado 0: no hay diálogo estructural porque falta canal,
frontera, diccionario o retorno. Estado U: hay indicios, canal parcial,
diccionario incompleto o retorno insuficiente; queda indeterminación
honesta. **Estado 1: hay canal consolidado, diccionario estructural y
retorno interpretable**. La clasificación no usa probabilidad como
verdad; usa condiciones. La consolidación de canal y semántica no
implica armonía, beneficio ni intención. Un virus puede consolidar canal
con célula y producir enfermedad; una galaxia puede consolidar canal con
agujero negro y producir reordenación dinámica; una bacteria puede
consolidar canal y producir simbiosis o sepsis. Diálogo estructural
significa que el intercambio tiene sentido de dominio, no que sea
positivo. Por eso toda consolidación debe ir acompañada de residual y
resultado.

### **XI.4. Residual semántico y retorno** {#xi4-residual-semntico-y-retorno}

El residual semántico aparece cuando los observables interactúan pero la
correspondencia no queda plenamente resuelta. Puede haber señal ambigua,
receptor compartido, respuesta cruzada, mimetismo estructural,
dominancia parcial. El residual semántico no debe ocultarse bajo una
etiqueta. **En astrofísica, gran parte del error de identificación
procede de atribuir sustancialidad a componentes gravitatorios que
permanecen en **`U`** por no cierre material**. La materia oscura,
identificada históricamente como sustancia espectral no observada, queda
reidentificada en el SV como densidad gravitatoria efectiva de sutura
`ρ_DM,sutura^SV`, con nulidad sustancial demostrada
`ρ_DM,sustancia^SV = 0` (Lloret Egea, 2026j). El residual queda
explícito y la lectura no clausura prematuramente. En biología, gran
parte del daño diagnóstico procede de no respetar el residual semántico:
se llama infección a colonización, tumor a masa, autoinmunidad a
autoanticuerpo, causa de muerte a diagnóstico no cerrado. El aparato de
la formulación impide ese salto en su forma estructural. El retorno
`R_AB` cierra la consolidación. Sin retorno verificable al dominio
respectivo, la consolidación queda en hipótesis no cerrada. El retorno
es operación interna del aparato del Sistema Vectorial SV y,
simultáneamente, condición de admisibilidad frente al dominio externo.
Una salida que no devuelva al dominio externo un resultado inteligible
queda inválida; una salida que devuelva resultado con residual gobernado
queda admitida bajo las condiciones declaradas.

------------------------------------------------------------------------

## **XII. Relación entre potencial local, comparador global y observables** {#xii-relacin-entre-potencial-local-comparador-global-y-observables}

### **XII.1. Potencial local y comparador global** {#xii1-potencial-local-y-comparador-global}

El potencial local `P_D(e)` y la magnitud global `Φ(τ)` no ocupan el
mismo plano. `P_D(e)` pertenece al régimen del suceso admisible y mide
separación polar dentro de un dominio declarado. `Φ(τ)` pertenece al
régimen del comparador con realimentación y mide desequilibrio
estructural del lazo que gobierna el dominio realizado como conjunto. La
relación entre ambos planos es formal, no identitaria: el plano local
proporciona la gramática de separación polar; el plano global organiza
esa gramática en una topología de autogobierno bajo `ε−0`, con
conservación de `U` como indeterminación honesta. **La comparación entre
ambos objetos queda prohibida si no se declara el dominio de paso**. No
procede escribir que `P_D(e)=Φ(τ)`, ni que `Φ(τ)` sea suma de
potenciales locales, ni que el potencial local contenga por sí solo el
ciclo del dominio realizado. La operación admisible consiste en
reconocer continuidad estructural: el suceso local muestra cómo se
calcula una separación polar bajo residual; el comparador global muestra
cómo la separación polar del dominio no clausura en reposo absoluto por
imperfección sostenida.

### **XII.2. Observables, sucesos y dominios** {#xii2-observables-sucesos-y-dominios}

Un observable no es un suceso. Un suceso puede hacer visible, modificar,
transportar o registrar un observable, pero no se identifica con él. El
observable queda gobernado por `𝓒★ObsU(x,D)` y por la familia de
transductores `𝓖★TrU(D)`; el suceso queda gobernado por horizonte,
soporte, operador de reevaluación, traza, potencial, residual y retorno.
La continuidad entre ambos exige dominio declarado, identidad, canal,
barrera, residual y retorno. Sin esos elementos, la lectura se conserva
en `U` o se rechaza si existe contradicción material. Esta separación
impide confundir potencial de suceso, tránsito de dominio y gobierno de
observable. La comunicación entre sucesos opera sobre diferencia de
potencial y trazabilidad; la comunicación entre observables opera sobre
canal, diccionario, transductor y retorno. Ambos planos son compatibles,
pero no intercambiables.

### **XII.3. Convención residual y predicado positivo** {#xii3-convencin-residual-y-predicado-positivo}

Los residuales cierran en `0`: `R=0` significa cierre, `R=1` significa
contradicción material o no admisión, y `R=U` conserva indeterminación
honesta. En cambio, los predicados positivos de consolidación cierran en
`1`: `Id_trans^SV=1`, `Canal_AB^Γ=1` o `Diag_AB^⊥=1` significan admisión
positiva del predicado. Esta distinción evita confundir residual nulo
con afirmación predicativa. La convención se aplica a todos los objetos.
`T_D^SV(D_i,D_j;x)=0 ⇔ R_D^SV(D_i,D_j;x)=0` expresa tránsito cerrado por
residual nulo. `x∈ObsU(D) ⇔ 𝓒★ObsU(x,D)=0` expresa observable fuerte por
cierre de la fórmula. `Diag_AB^⊥=1` expresa consolidación positiva de
canal, diccionario, retorno y residual semántico. No hay contradicción
entre estas escrituras: pertenecen a familias operativas distintas.

### **XII.4. Articulación con fundamentos, principios y otros documentos del SV** {#xii4-articulacin-con-fundamentos-principios-y-otros-documentos-del-sv}

#### **XII.4.1. Imperfección preformal y espacio** {#xii41-imperfeccin-preformal-y-espacio}

La genealogía formal de `ε−0` queda en *Imperfección preformal y
espacio: ε−0, primera distinguibilidad y dominio estructural completo de
separación factual recorrible* (Lloret Egea, 2026b). Este desarrollo
hereda esta formalización como condición preformal de todo el aparato.

#### **XII.4.2. Sucesos generadores y protocampos unificados** {#xii42-sucesos-generadores-y-protocampos-unificados}

La *Teoría general de sucesos generadores y de los protocampos
unificados en el Sistema Vectorial SV* (Lloret Egea, 2026c) provee el
sustrato dinámico-estructural sobre el que opera la formulación. Los
sucesos generadores constituyen unidad elemental de cambio estructural;
los protocampos unificados articulan sucesos que se inscriben antes de
su tipado por dominio.

#### **XII.4.3. Teoría del TODO y de la NADA como sede del inventario y de la identidad entrada-salida** {#xii43-teora-del-todo-y-de-la-nada-como-sede-del-inventario-y-de-la-identidad-entrada-salida}

La *Teoría del TODO y de la NADA en el Sistema Vectorial SV* (Lloret
Egea, 2026f) constituye la base formal de dos elementos de la
formulación. Provee el inventario completo de admisibilidad estructural
con criterios de admisión, no admisión e indeterminación honesta. Provee
también la identidad TODO = NADA que habilita el lazo realimentado del
autogobierno sin requerir canal externo. La articulación es doble:
inventario y topología.

#### **XII.4.4. Régimen H-He ordinario como caso de contraste del tránsito** {#xii44-rgimen-h-he-ordinario-como-caso-de-contraste-del-trnsito}

El régimen hidrógeno-helio de la materia ordinaria constituye caso de
contraste cuantitativo de la ley general del tránsito por dominios. El
documento sobre el origen material ordinario del Universo observable
(Lloret Egea, 2026k) formaliza la aplicación, articulando dominio
nuclear, dominio atómico y dominio molecular bajo residual gobernado, y
enlazando con la tabla periódica estructural del SV y con los pares
estructurales del Catálogo CPS-SV (Lloret Egea, 2026e). La continuidad
H--He queda gobernada por `Id_trans^SV`, con banco de contraste empírico
de la nucleosíntesis del Big Bang (Cyburt et al., 2016) y de la
espectroscopía atómica de hidrógeno (Beyer et al., 2017).

#### **XII.4.5. Densidad gravitatoria efectiva de sutura** {#xii45-densidad-gravitatoria-efectiva-de-sutura}

El componente gravitatorio históricamente atribuido a materia oscura
sustancial queda reidentificado en el SV como densidad gravitatoria
efectiva de sutura `ρ_DM,sutura^SV`, con nulidad sustancial demostrada
`ρ_DM,sustancia^SV = 0` (Lloret Egea, 2026j). El Bullet Cluster (Clowe
*et al*., 2006) queda releído como caso de contraste del componente
gravitatorio efectivo, no como evidencia de sustancia material no
observada.

#### **XII.4.6. Agujero negro como cierre interno sin resto exterior formulable** {#xii46-agujero-negro-como-cierre-interno-sin-resto-exterior-formulable}

El tratamiento estructural del agujero negro en el Sistema Vectorial SV
(Lloret Egea, 2026m) lo identifica como cierre interno sin resto
exterior formulable bajo la disciplina del SV. La articulación con la
formulación se ejecuta vía transductor `𝔛astr`, y la consolidación de
canal con observables externos queda gobernada por la fórmula
`Diag_AB^⊥` aplicada a este caso límite.

#### **XII.4.7. Proyecciones biológicas como aplicación del aparato universal** {#xii47-proyecciones-biolgicas-como-aplicacin-del-aparato-universal}

La aplicación del aparato `𝓒★ObsU — 𝓖★TrU(D)` al régimen biológico queda
formalizada en *Proyecciones biológicas de la fibra* (Lloret Egea,
2026l). La obra establece los transductores `𝔛bio`, `𝔛mut`, `𝔛var`,
`𝔛dis`, `𝔛onc`, `𝔛evo`, `𝔛human` con sus respectivos diccionarios,
bancos de contraste y casos límite. Articula simultáneamente, como
control transdominio, los transductores `𝔛astr` aplicados a
galaxia-agujero negro y a planeta-estrella, demostrando la universalidad
bajo especialización tipada.

#### **XII.4.8. Otros enlaces con el conjunto de fundamentos y documentos** {#xii48-otros-enlaces-con-el-conjunto-de-fundamentos-y-documentos}

El régimen ciclo-distancial `T_obs` queda formalizado en el Teorema de
resolución física de la constante cosmológica (Lloret Egea, 2026h). Las
edades relativas del universo observable y de sus objetos físicos quedan
articuladas en (Lloret Egea, 2026i). Los primitivos metrológicos del
Sistema Vectorial SV y la tabla de equivalencias factuales con el
Sistema Internacional quedan en (Lloret Egea, 2026g). La génesis del
hidrógeno y la teoría de la persistencia energética estructural quedan
en (Lloret Egea, 2026d).

------------------------------------------------------------------------

## **XIII. Matriz de correspondencia formal** {#xiii-matriz-de-correspondencia-formal}

+---+---------+---+---+---+---+
| * | **Apa   | * | * | * | * |
| * | rtado** | * | * | * | * |
| A |         | O | R | C | L |
| f |         | p | e | o | a |
| i |         | e | f | n | b |
| r |         | r | e | d | o |
| m |         | a | r | i | r |
| a |         | d | e | c | a |
| c |         | o | n | i | t |
| i |         | r | c | ó | o |
| ó |         | o | i | n | r |
| n |         | f | a | d | i |
| f |         | ó | f | e | o |
| o |         | r | o | c | a |
| r |         | m | r | i | s |
| m |         | u | m | e | o |
| a |         | l | a | r | c |
| l |         | a | l | r | i |
| * |         | * | * | e | a |
| * |         | * | * | * | d |
|   |         |   |   | * | o |
|   |         |   |   |   | * |
|   |         |   |   |   | * |
+===+=========+===+===+===+===+
| E | 0, XII  | ` | * | D | L |
| l |         | P | P | o | . |
| p |         | _ | o | m | 9 |
| o |         | D | t | i |   |
| t |         | ( | e | n |   |
| e |         | e | n | i |   |
| n |         | ) | c | o |   |
| c |         | = | i | d |   |
| i |         | μ | a | e |   |
| a |         | _ | l | c |   |
| l |         | D | d | l |   |
| l |         | ( | e | a |   |
| o |         | e | u | r |   |
| c |         | ) | n | a |   |
| a |         | − | s | d |   |
| l |         | λ | u | o |   |
| d |         | _ | c | , |   |
| e |         | D | e | r |   |
| l |         | ( | s | e |   |
| s |         | e | o | s |   |
| u |         | ) | * | i |   |
| c |         | ` |   | d |   |
| e |         | ; |   | u |   |
| s |         | ` |   | a |   |
| o |         | I |   | l |   |
| c |         | _ |   | d |   |
| o |         | D |   | e |   |
| n |         | ( |   | a |   |
| s |         | e |   | d |   |
| t |         | ) |   | m |   |
| i |         | = |   | i |   |
| t |         | μ |   | s |   |
| u |         | _ |   | i |   |
| y |         | D |   | b |   |
| e |         | ( |   | i |   |
| e |         | e |   | l |   |
| l |         | ) |   | i |   |
| f |         | + |   | d |   |
| u |         | λ |   | a |   |
| n |         | _ |   | d |   |
| d |         | D |   | , |   |
| a |         | ( |   | t |   |
| m |         | e |   | r |   |
| e |         | ) |   | a |   |
| n |         | ` |   | z |   |
| t |         |   |   | a |   |
| o |         |   |   | y |   |
| d |         |   |   | r |   |
| e |         |   |   | e |   |
| l |         |   |   | t |   |
| e |         |   |   | o |   |
| c |         |   |   | r |   |
| t |         |   |   | n |   |
| u |         |   |   | o |   |
| r |         |   |   | . |   |
| a |         |   |   |   |   |
| p |         |   |   |   |   |
| o |         |   |   |   |   |
| l |         |   |   |   |   |
| a |         |   |   |   |   |
| r |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+
| E | IV, XII | ` | * | D | L |
| l |         | Φ | P | i | . |
| c |         | ( | o | s | 1 |
| o |         | τ | t | t |   |
| m |         | ) | e | i |   |
| p |         | = | n | n |   |
| a |         | Φ | c | c |   |
| r |         | _ | i | i |   |
| a |         | p | a | ó |   |
| d |         | o | l | n |   |
| o |         | l | d | d |   |
| r |         | o | e | e |   |
| g |         | _ | u | p |   |
| l |         | 0 | n | l |   |
| o |         | ( | s | a |   |
| b |         | τ | u | n |   |
| a |         | ) | c | o |   |
| l |         | − | e | e |   |
| n |         | Φ | s | n |   |
| o |         | _ | o | t |   |
| s |         | p | * | r |   |
| e |         | o | ; | e |   |
| i |         | l | * | s |   |
| d |         | o | T | u |   |
| e |         | _ | e | c |   |
| n |         | 1 | o | e |   |
| t |         | ( | r | s |   |
| i |         | τ | í | o |   |
| f |         | ) | a | l |   |
| i |         | ` | d | o |   |
| c |         |   | e | c |   |
| a |         |   | l | a |   |
| c |         |   | T | l |   |
| o |         |   | O | y |   |
| n |         |   | D | l |   |
| e |         |   | O | a |   |
| l |         |   | y | z |   |
| p |         |   | d | o |   |
| o |         |   | e | g |   |
| t |         |   | l | l |   |
| e |         |   | a | o |   |
| n |         |   | N | b |   |
| c |         |   | A | a |   |
| i |         |   | D | l |   |
| a |         |   | A | . |   |
| l |         |   | * |   |   |
| l |         |   |   |   |   |
| o |         |   |   |   |   |
| c |         |   |   |   |   |
| a |         |   |   |   |   |
| l |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+
| L | II, IV  | ` | * | C | L |
| a |         | ε | I | a | . |
| r |         | − | m | d | 1 |
| u |         | 0 | p | e |   |
| p |         |   | e | n |   |
| t |         | ⊢ | r | a |   |
| u |         |   | f | p |   |
| r |         | ∂ | e | r |   |
| a |         | ε | c | e |   |
| d |         |   | c | f |   |
| e |         | ⊢ | i | o |   |
| e |         |   | ó | r |   |
| q |         | D | n | m |   |
| u |         | s | p | a |   |
| i |         | e | r | l |   |
| p |         | p | e | s |   |
| o |         |   | f | i |   |
| t |         | ⊢ | o | n |   |
| e |         |   | r | d |   |
| n |         | Ω | m | u |   |
| c |         | e | a | p |   |
| i |         | s | l | l |   |
| a |         | p | y | i |   |
| l |         | ` | e | c |   |
| i |         | ; | s | a |   |
| d |         | ` | p | c |   |
| a |         | Φ | a | i |   |
| d |         | ( | c | ó |   |
| p |         | τ | i | n |   |
| r |         | _ | o | d |   |
| o |         | 0 | * | e |   |
| c |         | ) |   | f |   |
| e |         | ≠ |   | u |   |
| d |         | 0 |   | n |   |
| e |         | ` |   | d |   |
| d |         |   |   | a |   |
| e |         |   |   | m |   |
| ` |         |   |   | e |   |
| ε |         |   |   | n |   |
| − |         |   |   | t |   |
| 0 |         |   |   | o |   |
| ` |         |   |   | . |   |
| y |         |   |   |   |   |
| n |         |   |   |   |   |
| o |         |   |   |   |   |
| d |         |   |   |   |   |
| e |         |   |   |   |   |
| a |         |   |   |   |   |
| g |         |   |   |   |   |
| e |         |   |   |   |   |
| n |         |   |   |   |   |
| t |         |   |   |   |   |
| e |         |   |   |   |   |
| e |         |   |   |   |   |
| x |         |   |   |   |   |
| t |         |   |   |   |   |
| e |         |   |   |   |   |
| r |         |   |   |   |   |
| n |         |   |   |   |   |
| o |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+
| L | V       | ` | * | C | L |
| a |         | l | T | o | . |
| c |         | i | e | n | 2 |
| o |         | m | o | s |   |
| n |         | _ | r | e |   |
| v |         | { | í | r |   |
| e |         | τ | a | v |   |
| r |         | → | d | a |   |
| g |         | ∞ | e | c |   |
| e |         | } | l | i |   |
| n |         |   | T | ó |   |
| c |         | Φ | O | n |   |
| i |         | ( | D | d |   |
| a |         | τ | O | e |   |
| n |         | ) | y | ` |   |
| o |         | = | d | U |   |
| c |         | Φ | e | ` |   |
| l |         | _ | l | y |   |
| a |         | ∞ | a | a |   |
| u |         | ≠ | N | u |   |
| s |         | 0 | A | s |   |
| u |         | ` | D | e |   |
| r |         | b | A | n |   |
| a |         | a | * | c |   |
| e |         | j | ; | i |   |
| n |         | o | * | a |   |
| r |         | ` | I | d |   |
| e |         | ξ | m | e |   |
| p |         | ( | p | c |   |
| o |         | ε | e | i |   |
| s |         | − | r | e |   |
| o |         | 0 | f | r |   |
| a |         | ) | e | r |   |
| b |         | ` | c | e |   |
| s |         |   | c | b |   |
| o |         |   | i | i |   |
| l |         |   | ó | n |   |
| u |         |   | n | a |   |
| t |         |   | p | r |   |
| o |         |   | r | i |   |
| m |         |   | e | o |   |
| i |         |   | f | f |   |
| e |         |   | o | o |   |
| n |         |   | r | r |   |
| t |         |   | m | z |   |
| r |         |   | a | a |   |
| a |         |   | l | d |   |
| s |         |   | y | o |   |
| s |         |   | e | . |   |
| u |         |   | s |   |   |
| b |         |   | p |   |   |
| s |         |   | a |   |   |
| i |         |   | c |   |   |
| s |         |   | i |   |   |
| t |         |   | o |   |   |
| a |         |   | * |   |   |
| i |         |   |   |   |   |
| m |         |   |   |   |   |
| p |         |   |   |   |   |
| e |         |   |   |   |   |
| r |         |   |   |   |   |
| f |         |   |   |   |   |
| e |         |   |   |   |   |
| c |         |   |   |   |   |
| c |         |   |   |   |   |
| i |         |   |   |   |   |
| ó |         |   |   |   |   |
| n |         |   |   |   |   |
| s |         |   |   |   |   |
| o |         |   |   |   |   |
| s |         |   |   |   |   |
| t |         |   |   |   |   |
| e |         |   |   |   |   |
| n |         |   |   |   |   |
| i |         |   |   |   |   |
| d |         |   |   |   |   |
| a |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+
| ` | VI      | ` | T | L | L |
| T |         | T | e | e | . |
| _ |         | _ | o | c | 3 |
| o |         | o | r | t |   |
| b |         | b | e | u |   |
| s |         | s | m | r |   |
| ` |         | ≈ | a | a |   |
| o |         | 4 | d | c |   |
| p |         | , | e | i |   |
| e |         | 3 | r | c |   |
| r |         | 5 | e | l |   |
| a |         | 4 | s | o |   |
| c |         | 9 | o | - |   |
| o |         | 4 | l | d |   |
| m |         | 8 | u | i |   |
| o |         | 8 | c | s |   |
| r |         | 0 | i | t |   |
| é |         | 0 | ó | a |   |
| g |         | × | n | n |   |
| i |         | 1 | f | c |   |
| m |         | 0 | í | i |   |
| e |         | ¹ | s | a |   |
| n |         | ⁷ | i | l |   |
| c |         |   | c | s |   |
| i |         | s | a | i |   |
| c |         | ` | d | n |   |
| l |         | ; | e | t |   |
| o |         | ` | l | r |   |
| - |         | T | a | a |   |
| d |         | _ | c | n |   |
| i |         | c | o | s |   |
| s |         | i | n | m |   |
| t |         | c | s | i |   |
| a |         | l | t | s |   |
| n |         | o | a | i |   |
| c |         | ≈ | n | ó |   |
| i |         | 2 | t | n |   |
| a |         | T | e | f |   |
| l |         | _ | c | í |   |
| , |         | o | o | s |   |
| n |         | b | s | i |   |
| o |         | s | m | c |   |
| c |         | ` | o | a |   |
| o |         |   | l | a |   |
| m |         |   | ó | l |   |
| o |         |   | g | u |   |
| t |         |   | i | n |   |
| i |         |   | c | í |   |
| e |         |   | a | s |   |
| m |         |   |   | o |   |
| p |         |   |   | n |   |
| o |         |   |   | o |   |
| r |         |   |   | . |   |
| e |         |   |   |   |   |
| c |         |   |   |   |   |
| t |         |   |   |   |   |
| o |         |   |   |   |   |
| r |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+
| L | IX      | ` | * | C | L |
| a |         | T | E | i | . |
| c |         | _ | l | e | 4 |
| o |         | D | o | r |   |
| n |         | ^ | r | r |   |
| t |         | S | i | e |   |
| i |         | V | g | d |   |
| n |         | ( | e | e |   |
| u |         | D | n | d |   |
| i |         | _ | m | o |   |
| d |         | i | a | m |   |
| a |         | , | t | i |   |
| d |         | D | e | n |   |
| e |         | _ | r | i |   |
| n |         | j | i | o |   |
| t |         | ; | a | , |   |
| r |         | x | l | i |   |
| e |         | ) | o | d |   |
| d |         | = | r | e |   |
| o |         | 0 | d | n |   |
| m |         |   | i | t |   |
| i |         | ⇔ | n | i |   |
| n |         |   | a | d |   |
| i |         | R | r | a |   |
| o |         | _ | i | d |   |
| s |         | D | o | , |   |
| e |         | ^ | d | e |   |
| x |         | S | e | s |   |
| i |         | V | l | t |   |
| g |         | ( | U | a |   |
| e |         | D | n | d |   |
| r |         | _ | i | o |   |
| e |         | i | v | , |   |
| s |         | , | e | f |   |
| i |         | D | r | r |   |
| d |         | _ | s | o |   |
| u |         | j | o | n |   |
| a |         | ; | o | t |   |
| l |         | x | b | e |   |
| n |         | ) | s | r |   |
| u |         | = | e | a |   |
| l |         | 0 | r | , |   |
| o |         | ` | v | c |   |
| . |         |   | a | a |   |
|   |         |   | b | n |   |
|   |         |   | l | a |   |
|   |         |   | e | l |   |
|   |         |   | * | , |   |
|   |         |   |   | t |   |
|   |         |   |   | r |   |
|   |         |   |   | a |   |
|   |         |   |   | z |   |
|   |         |   |   | a |   |
|   |         |   |   | y |   |
|   |         |   |   | r |   |
|   |         |   |   | e |   |
|   |         |   |   | t |   |
|   |         |   |   | o |   |
|   |         |   |   | r |   |
|   |         |   |   | n |   |
|   |         |   |   | o |   |
|   |         |   |   | . |   |
+---+---------+---+---+---+---+
| L | IX      | ` | * | R | L |
| a |         | I | E | e | . |
| i |         | d | l | s | 4 |
| d |         | _ | o | i |   |
| e |         | t | r | d |   |
| n |         | r | i | u |   |
| t |         | a | g | a |   |
| i |         | n | e | l |   |
| d |         | s | n | c |   |
| a |         | ^ | m | o |   |
| d |         | S | a | m |   |
| d |         | V | t | p |   |
| e |         | ( | e | u |   |
| t |         | x | r | e |   |
| r |         | ; | i | s |   |
| á |         | Γ | a | t |   |
| n |         | _ | l | o |   |
| s |         | D | o | a |   |
| i |         | ) | r | n |   |
| t |         | = | d | u |   |
| o |         | 1 | i | l |   |
| e |         |   | n | a |   |
| x |         | ⇔ | a | d |   |
| i |         |   | r | o |   |
| g |         | ⊕ | i | e |   |
| e |         | _ | o | n |   |
| c |         | i | d | c |   |
| i |         |   | e | a |   |
| e |         | R | l | d |   |
| r |         | _ | U | a |   |
| r |         | D | n | t |   |
| e |         | ^ | i | r |   |
| e |         | S | v | á |   |
| n |         | V | e | n |   |
| t |         | ( | r | s |   |
| o |         | D | s | i |   |
| d |         | _ | o | t |   |
| a |         | i | o | o |   |
| c |         | , | b | l |   |
| a |         | D | s | o |   |
| d |         | _ | e | c |   |
| e |         | { | r | a |   |
| n |         | i | v | l |   |
| a |         | + | a | . |   |
| f |         | 1 | b |   |   |
| i |         | } | l |   |   |
| n |         | ; | e |   |   |
| i |         | x | * |   |   |
| t |         | ) |   |   |   |
| a |         | = |   |   |   |
| d |         | 0 |   |   |   |
| e |         | ` |   |   |   |
| d |         |   |   |   |   |
| o |         |   |   |   |   |
| m |         |   |   |   |   |
| i |         |   |   |   |   |
| n |         |   |   |   |   |
| i |         |   |   |   |   |
| o |         |   |   |   |   |
| s |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+
| L | X       | ` | * | C | L |
| a |         | 𝓒 | P | i | . |
| o |         | ★ | r | e | 5 |
| b |         | O | o | r |   |
| s |         | b | y | r |   |
| e |         | s | e | e |   |
| r |         | U | c | d |   |
| v |         | ( | c | e |   |
| a |         | x | i | m |   |
| b |         | , | o | a |   |
| i |         | D | n | g |   |
| l |         | ) | e | n |   |
| i |         | ∈ | s | i |   |
| d |         | { | b | t |   |
| a |         | 0 | i | u |   |
| d |         | , | o | d |   |
| f |         | 1 | l | e |   |
| u |         | , | ó | s |   |
| e |         | U | g | , |   |
| r |         | } | i | t |   |
| t |         | ` | c | r |   |
| e |         |   | a | a |   |
| s |         |   | s | n |   |
| e |         |   | d | s |   |
| d |         |   | e | d |   |
| e |         |   | l | u |   |
| c |         |   | a | c |   |
| i |         |   | f | c |   |
| d |         |   | i | i |   |
| e |         |   | b | ó |   |
| p |         |   | r | n |   |
| o |         |   | a | , |   |
| r |         |   | * | f |   |
| l |         |   |   | r |   |
| a |         |   |   | o |   |
| f |         |   |   | n |   |
| ó |         |   |   | t |   |
| r |         |   |   | e |   |
| m |         |   |   | r |   |
| u |         |   |   | a |   |
| l |         |   |   | , |   |
| a |         |   |   | i |   |
| u |         |   |   | d |   |
| n |         |   |   | e |   |
| i |         |   |   | n |   |
| v |         |   |   | t |   |
| e |         |   |   | i |   |
| r |         |   |   | d |   |
| s |         |   |   | a |   |
| a |         |   |   | d |   |
| l |         |   |   | , |   |
| . |         |   |   | c |   |
|   |         |   |   | a |   |
|   |         |   |   | n |   |
|   |         |   |   | a |   |
|   |         |   |   | l |   |
|   |         |   |   | , |   |
|   |         |   |   | b |   |
|   |         |   |   | a |   |
|   |         |   |   | r |   |
|   |         |   |   | r |   |
|   |         |   |   | e |   |
|   |         |   |   | r |   |
|   |         |   |   | a |   |
|   |         |   |   | , |   |
|   |         |   |   | r |   |
|   |         |   |   | e |   |
|   |         |   |   | s |   |
|   |         |   |   | i |   |
|   |         |   |   | d |   |
|   |         |   |   | u |   |
|   |         |   |   | a |   |
|   |         |   |   | l |   |
|   |         |   |   | , |   |
|   |         |   |   | r |   |
|   |         |   |   | e |   |
|   |         |   |   | t |   |
|   |         |   |   | o |   |
|   |         |   |   | r |   |
|   |         |   |   | n |   |
|   |         |   |   | o |   |
|   |         |   |   | y |   |
|   |         |   |   | t |   |
|   |         |   |   | r |   |
|   |         |   |   | a |   |
|   |         |   |   | z |   |
|   |         |   |   | a |   |
|   |         |   |   | . |   |
+---+---------+---+---+---+---+
| T | X, XI   | ` | * | E | L |
| o |         | 𝓖 | P | s | . |
| d |         | ★ | r | p | 6 |
| o |         | T | o | e |   |
| t |         | r | y | c |   |
| r |         | U | e | i |   |
| a |         | ( | c | a |   |
| n |         | D | c | l |   |
| s |         | ) | i | i |   |
| d |         | = | o | z |   |
| u |         | 𝔛 | n | a |   |
| c |         | _ | e | c |   |
| t |         | { | s | i |   |
| o |         | D | b | ó |   |
| r |         | ↔ | i | n |   |
| l |         | S | o | t |   |
| e |         | V | l | i |   |
| g |         | } | ó | p |   |
| í |         | ` | g | a |   |
| t |         |   | i | d |   |
| i |         |   | c | a |   |
| m |         |   | a | p |   |
| o |         |   | s | o |   |
| d |         |   | d | r |   |
| e |         |   | e | d |   |
| r |         |   | l | o |   |
| i |         |   | a | m |   |
| v |         |   | f | i |   |
| a |         |   | i | n |   |
| d |         |   | b | i |   |
| e |         |   | r | o |   |
| l |         |   | a | s |   |
| a |         |   | * | i |   |
| f |         |   | ; | n |   |
| ó |         |   | * | a |   |
| r |         |   | P | n |   |
| m |         |   | r | a |   |
| u |         |   | i | l |   |
| l |         |   | m | o |   |
| a |         |   | i | g |   |
| u |         |   | t | í |   |
| n |         |   | i | a |   |
| i |         |   | v | l |   |
| v |         |   | o | i |   |
| e |         |   | s | b |   |
| r |         |   | m | r |   |
| s |         |   | e | e |   |
| a |         |   | t | . |   |
| l |         |   | r |   |   |
| . |         |   | o |   |   |
|   |         |   | l |   |   |
|   |         |   | ó |   |   |
|   |         |   | g |   |   |
|   |         |   | i |   |   |
|   |         |   | c |   |   |
|   |         |   | o |   |   |
|   |         |   | s |   |   |
|   |         |   | * |   |   |
+---+---------+---+---+---+---+
| L | XI      | ` | * | C | L |
| a |         | D | P | a | . |
| c |         | i | o | n | 7 |
| o |         | a | t | a |   |
| m |         | g | e | l |   |
| u |         | _ | n | t |   |
| n |         | A | c | r |   |
| i |         | B | i | a |   |
| c |         | ^ | a | z |   |
| a |         | ⊥ | l | a |   |
| c |         | = | d | d |   |
| i |         | 1 | e | o |   |
| ó |         |   | u | , |   |
| n |         | ⇔ | n | d |   |
| e |         |   | s | i |   |
| s |         | C | u | c |   |
| t |         | a | c | c |   |
| r |         | n | e | i |   |
| u |         | a | s | o |   |
| c |         | l | o | n |   |
| t |         | _ | * | a |   |
| u |         | A | ; | r |   |
| r |         | B | * | i |   |
| a |         | ^ | P | o |   |
| l |         | Γ | r | a |   |
| e |         | = | o | p |   |
| n |         | 1 | y | t |   |
| t |         |   | e | o |   |
| r |         | ∧ | c | , |   |
| e |         |   | c | r |   |
| o |         | 𝓓 | i | e |   |
| b |         | _ | o | t |   |
| s |         | A | n | o |   |
| e |         | B | e | r |   |
| r |         | ^ | s | n |   |
| v |         | ⊥ | b | o |   |
| a |         |   | i | y |   |
| b |         | a | o | r |   |
| l |         | p | l | e |   |
| e |         | t | ó | s |   |
| s |         | o | g | i |   |
| e |         |   | i | d |   |
| x |         | ∧ | c | u |   |
| i |         |   | a | a |   |
| g |         | R | s | l |   |
| e |         | _ | d | s |   |
| c |         | A | e | e |   |
| a |         | B | l | m |   |
| n |         |   | a | á |   |
| a |         | t | f | n |   |
| l |         | r | i | t |   |
| , |         | a | b | i |   |
| d |         | z | r | c |   |
| i |         | a | a | o |   |
| c |         | d | * | . |   |
| c |         | o |   |   |   |
| i |         |   |   |   |   |
| o |         | ∧ |   |   |   |
| n |         |   |   |   |   |
| a |         | Δ |   |   |   |
| r |         | _ |   |   |   |
| i |         | s |   |   |   |
| o |         | e |   |   |   |
| , |         | m |   |   |   |
| r |         |   |   |   |   |
| e |         | a |   |   |   |
| s |         | d |   |   |   |
| i |         | m |   |   |   |
| d |         | i |   |   |   |
| u |         | s |   |   |   |
| a |         | i |   |   |   |
| l |         | b |   |   |   |
| y |         | l |   |   |   |
| r |         | e |   |   |   |
| e |         | ` |   |   |   |
| t |         |   |   |   |   |
| o |         |   |   |   |   |
| r |         |   |   |   |   |
| n |         |   |   |   |   |
| o |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+
| L | VII     | ` | * | C | L |
| a |         | P | P | o | . |
| p |         | r | r | n | 8 |
| r |         | e | o | s |   |
| e |         | d | y | e |   |
| d |         | _ | e | r |   |
| o |         | A | c | v |   |
| m |         | B | c | a |   |
| i |         | ^ | i | c |   |
| n |         | c | o | i |   |
| a |         | o | n | ó |   |
| n |         | m | e | n |   |
| c |         | p | s | o |   |
| i |         | a | b | d |   |
| a |         | t | i | e |   |
| c |         | ` | o | s |   |
| o |         | ; | l | t |   |
| m |         | ` | ó | r |   |
| p |         | P | g | u |   |
| a |         | r | i | c |   |
| t |         | e | c | c |   |
| i |         | d | a | i |   |
| b |         | _ | s | ó |   |
| l |         | A | d | n |   |
| e |         | B | e | f |   |
| y |         | ^ | l | u |   |
| l |         | l | a | n |   |
| a |         | e | f | c |   |
| l |         | s | i | i |   |
| e |         | i | b | o |   |
| s |         | v | r | n |   |
| i |         | a | a | a |   |
| v |         | ` | * | l |   |
| a |         |   | ; | b |   |
| s |         |   | d | a |   |
| e |         |   | o | j |   |
| d |         |   | c | o |   |
| i |         |   | u | c |   |
| s |         |   | m | a |   |
| t |         |   | e | p |   |
| i |         |   | n | t |   |
| n |         |   | t | u |   |
| g |         |   | o | r |   |
| u |         |   | s | a |   |
| e |         |   | a | a |   |
| n |         |   | s | s |   |
| p |         |   | t | i |   |
| o |         |   | r | m |   |
| r |         |   | o | é |   |
| e |         |   | f | t |   |
| l |         |   | í | r |   |
| e |         |   | s | i |   |
| s |         |   | i | c |   |
| t |         |   | c | a |   |
| a |         |   | o | . |   |
| d |         |   | s |   |   |
| o |         |   | S |   |   |
| d |         |   | V |   |   |
| e |         |   |   |   |   |
| l |         |   |   |   |   |
| s |         |   |   |   |   |
| u |         |   |   |   |   |
| b |         |   |   |   |   |
| - |         |   |   |   |   |
| l |         |   |   |   |   |
| a |         |   |   |   |   |
| z |         |   |   |   |   |
| o |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+
| L | XIII-XV | M | F | C | L |
| a |         | a | u | i | . |
| a |         | t | n | e | 9 |
| r |         | r | d | r |   |
| q |         | i | a | r |   |
| u |         | z | m | e |   |
| i |         | i | e | c |   |
| t |         | n | n | o |   |
| e |         | t | t | n |   |
| c |         | e | o | j |   |
| t |         | g | s | u |   |
| u |         | r | , | n |   |
| r |         | a | p | t |   |
| a |         | d | r | o |   |
| c |         | a | i | s |   |
| o |         |   | n | i |   |
| m |         |   | c | n |   |
| p |         |   | i | t |   |
| l |         |   | p | i |   |
| e |         |   | i | e |   |
| t |         |   | o | m |   |
| a |         |   | s | p |   |
| e |         |   | y | o |   |
| x |         |   | d | r |   |
| i |         |   | o | e |   |
| g |         |   | c | c |   |
| e |         |   | u | t |   |
| i |         |   | m | o |   |
| n |         |   | e | r |   |
| t |         |   | n | , |   |
| e |         |   | t | a |   |
| g |         |   | o | g |   |
| r |         |   | s | e |   |
| a |         |   | c | n |   |
| c |         |   | i | c |   |
| i |         |   | t | i |   |
| ó |         |   | a | a |   |
| n |         |   | d | n |   |
| d |         |   | o | i |   |
| e |         |   | s | c |   |
| c |         |   |   | i |   |
| o |         |   |   | e |   |
| m |         |   |   | r |   |
| p |         |   |   | r |   |
| a |         |   |   | e |   |
| r |         |   |   | p |   |
| a |         |   |   | r |   |
| d |         |   |   | o |   |
| o |         |   |   | b |   |
| r |         |   |   | a |   |
| , |         |   |   | b |   |
| t |         |   |   | i |   |
| r |         |   |   | l |   |
| á |         |   |   | í |   |
| n |         |   |   | s |   |
| s |         |   |   | t |   |
| i |         |   |   | i |   |
| t |         |   |   | c |   |
| o |         |   |   | o |   |
| , |         |   |   | . |   |
| o |         |   |   |   |   |
| b |         |   |   |   |   |
| s |         |   |   |   |   |
| e |         |   |   |   |   |
| r |         |   |   |   |   |
| v |         |   |   |   |   |
| a |         |   |   |   |   |
| b |         |   |   |   |   |
| l |         |   |   |   |   |
| e |         |   |   |   |   |
| y |         |   |   |   |   |
| c |         |   |   |   |   |
| o |         |   |   |   |   |
| m |         |   |   |   |   |
| u |         |   |   |   |   |
| n |         |   |   |   |   |
| i |         |   |   |   |   |
| c |         |   |   |   |   |
| a |         |   |   |   |   |
| c |         |   |   |   |   |
| i |         |   |   |   |   |
| ó |         |   |   |   |   |
| n |         |   |   |   |   |
| . |         |   |   |   |   |
+---+---------+---+---+---+---+

## **XIV. Alcance declarado y condiciones de refutación** {#xiv-alcance-declarado-y-condiciones-de-refutacin}

### **XIV.1. Lo que se afirma** {#xiv1-lo-que-se-afirma}

**Este planteamiento afirma**:

-   Estructura formal del Universo físico realizado bajo el SV, en plano
    físico-formal y no metafísico.

-   Subordinación de la estructura matemática al cierre rector:
    comparecencia tras la primera distinguibilidad; no fundación
    exterior; codificación y decodificación del funcionamiento del
    dominio realizado desde dentro.

-   Imperfección preformal `ε−0` y fibra primigenia de observabilidad
    `𝓕−0^Obs = ε−0|Obs` como base formal de toda observabilidad.

-   Autogobierno topológico del dominio realizado mediante comparador
    con realimentación bajo identidad TODO = NADA, con ruptura simétrica
    espontánea por `ε−0` y convergencia asintótica gobernada con `U`
    preservada como indeterminación honesta donde no procede cierre
    binario.

-   Régimen ciclo-distancial `T_obs ≈ 4,354948800 × 10¹⁷ s` como
    horizonte estructural de toda propagación física coherente; ciclo
    completo del dominio realizado del orden de `T_obs × 2`.

-   Predominancia compatible y predominancia lesiva como configuraciones
    del lazo bajo captura asimétrica con o sin destrucción funcional.

-   Ley general del tránsito por dominios
    `T_D^SV — R_D^SV — Id_trans^SV` como aparato de continuidad entre
    dominios distinguibles bajo residual controlado.

-   Fórmula universal de gobierno de observables
    `𝓒★ObsU(x, D) ∈ {0, 1, U}` como criterio de admisibilidad
    estructural en cualquier dominio declarable, con familia derivada
    `𝓖★TrU(D)` por especialización tipada.

-   Comunicación estructural entre familias distintas de observables
    bajo canal, diccionario semántico estructural `𝓓_AB^⊥`, fórmula de
    consolidación `Diag_AB^⊥`, predominancia, residual y retorno.

-   Ensamble articulado de autogobierno topológico y comunicación
    estructural bajo principio rector único.

-   Articulación con fundamentos, principios y otros documentos del
    Sistema Vectorial SV bajo cifras canónicas heredadas.

### **XIV.2. Lo que no se afirma** {#xiv2-lo-que-no-se-afirma}

Esta tesis no afirma:

-   Consciencia distribuida del Universo bajo ninguna forma.

-   Panpsiquismo, protosintiencia universal ni interpretación sintiente
    del lazo realimentado.

-   Teleología, propósito, diseño, intencionalidad cósmica.

-   Omnisciencia, omnipotencia, omnipresencia en sentido teológico.

-   Equivalencia ontológica fuerte entre realidad física y estructura
    matemática en sentido tegmarkiano máximo.

-   Predicción experimental nueva sobre observables físicos
    contemporáneos como anuncio de ruptura del paradigma vigente.

-   Sustancialidad del componente gravitatorio históricamente atribuido
    a materia oscura.

-   Transmisión física coherente al unísono entre puntos separados por
    una distancia mayor que `c · T_obs`.

-   Diálogo en sentido sintiente entre observables; el término
    «comunicación estructural» refiere a consolidación formal de canal,
    diccionario y retorno, no a interacción consciente.

-   Reducción de la indeterminación honesta `U` a probabilidad
    estadística, a ruido eliminable o a estado epistémico provisional.

-   Anticipación temporal verificable del fin del ciclo de `T_obs × 2`
    bajo observador situado en el ciclo en curso. La hipótesis cíclica
    del autogobierno es estructural, no profética.

### **XIV.3. Condiciones de refutación** {#xiv3-condiciones-de-refutacin}

Queda sometido a las siguientes condiciones de refutación, declaradas
para preservar su falsabilidad:

-   Identificación experimental verificable de un canal físico que
    sostenga comunicación coherente al unísono entre dos puntos del
    Universo físico realizado separados por una distancia mayor que
    `c · T_obs` refutaría el principio rector del autogobierno
    topológico.

-   Demostración formal de inconsistencia interna entre el lazo de
    realimentación y la imperfección preformal `ε−0` refutaría la
    convergencia asintótica gobernada.

-   Identificación de un dominio observable del Universo físico
    realizado que opere fuera de toda dinámica de reequilibrio
    compatible con la dinámica del lazo refutaría la generalidad del
    autogobierno topológico.

-   Demostración formal de inconsistencia interna de la fórmula
    universal `𝓒★ObsU` o de la familia derivada `𝓖★TrU(D)` refutaría el
    gobierno de observables.

-   Demostración formal de inconsistencia entre la ley general del
    tránsito `T_D^SV — R_D^SV — Id_trans^SV` y un caso cuantitativo del
    régimen H-He ordinario refutaría la ley general del tránsito en su
    aplicación.

-   Identificación experimental de sustancialidad espectral material del
    componente gravitatorio convencionalmente atribuido a materia
    oscura, con verificación reproducible bajo banco de contraste,
    refutaría la nulidad sustancial declarada.

-   Demostración formal de circularidad estructural en la cadena
    `ε−0 ⊢ 𝓕−0^Obs ⊢ ∂Obs ⊢ DObs ⊢ ObsU(D)` refutaría la fibra
    primigenia de observabilidad.

------------------------------------------------------------------------

## **XV. Laboratorios** {#xv-laboratorios}

Los laboratorios asociados cumplen función de verificación computacional
de consistencia formal, no de sustitución de validación física externa.
Cada laboratorio debe declarar entradas, restricciones, salida esperada,
salida obtenida, residual y condición de aceptación. Ningún laboratorio
podrá convertir `U` en valor numérico ni cerrar favorablemente por
ausencia de contradicción.

  **Laboratorio**   **Objeto**                                                     **Fórmulas o restricciones**                                                                       **Resultado esperado**
  ----------------- -------------------------------------------------------------- -------------------------------------------------------------------------------------------------- ---------------------------------------------------------------------------------------------
  L.1               Comparador con realimentación y ruptura de equipotencialidad   `Φ_0=0`; `Φ(τ_0)≠0`; `ε−0`                                                                         Ruptura controlada sin agente externo.
  L.2               Convergencia asintótica gobernada y conservación de `U`        `dΦ/dτ=−γ·Φ+ξ(ε−0)`; `Φ_∞≠0`                                                                       No clausura a reposo absoluto.
  L.3               Régimen ciclo-distancial y topología sin transmisión           `T_obs`; `T_ciclo≈2T_obs`; límite `c·T_obs`                                                        Separación entre cambio físico con latencia y propiedad topológica no propagativa.
  L.4               Ley general del tránsito por dominios                          `T_D^SV=0 ⇔ R_D^SV=0`; `Id_trans^SV`                                                               Cierre sólo si todas las restricciones locales anulan residual.
  L.5               Fórmula universal de gobierno de observables                   `𝓒★ObsU(x,D)∈{0,1,U}`                                                                              Admisión, no admisión o `U` sin cierre impropio.
  L.6               Familia de transductores `𝓖★TrU(D)`                            `𝔛_{D↔SV}` con dominio, magnitud, frontera, identidad, canal, barrera, residual, retorno y traza   Transductor legítimo sólo por especialización tipada.
  L.7               Canal, diccionario semántico estructural y `Diag_AB^⊥`         `Canal_AB^Γ`; `𝓓_AB^⊥`; `R_AB`; `Δ_sem`                                                            Consolidación positiva sólo con canal, diccionario, retorno y residual.
  L.8               Predominancia compatible y predominancia lesiva                `Pred_AB^compat`; `Pred_AB^lesiva`                                                                 Distinción estructural entre asimetría gobernada y captura lesiva.
  L.9               Matriz integrada de autogobierno y comunicación estructural    Correspondencia formal completa                                                                    Integración sin tiempo rector, sintiencia, transmisión al unísono ni probabilidad fundante.

Los laboratorios quedan vinculados a los apartados de esta tesis
mediante su objeto verificable, sus fórmulas o restricciones y su
resultado esperado. La validación material exigirá, para cada banco,
datos de entrada, salida esperada, salida obtenida, residual explícito y
condición de aceptación.

### **XV.1. Tabla de ejecutables de los laboratorios** {#xv1-tabla-de-ejecutables-de-los-laboratorios}

La tabla enlaza cada laboratorio con su ejecutor reproducible.

  **Familia**                **Laboratorio**                          **Qué verifica**                                                                              **Ejecución**
  -------------------------- ---------------------------------------- --------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Comparador                 L.1. Comparador con realimentación       Ruptura de equipotencialidad y comparador global sin agente externo.                          [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L1_comparador_realimentacion/runner.py "null")
  Convergencia y U           L.2. Convergencia asintótica gobernada   No clausura a reposo absoluto y conservación de `U`.                                          [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L2_convergencia_asintotica_U/runner.py "null")
  Régimen ciclo-distancial   L.3. Topología sin transmisión           Separación entre latencia física y propiedad topológica no propagativa.                       [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L3_regimen_ciclo_distancial/runner.py "null")
  Tránsito por dominios      L.4. Ley general del tránsito            Cierre de tránsito sólo con residual nulo en restricciones locales.                           [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L4_transito_dominios/runner.py "null")
  Gobierno de observables    L.5. Fórmula universal de observables    Admisión, no admisión o `U` sin cierre impropio.                                              [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L5_gobierno_observables/runner.py "null")
  Transductores              L.6. Familia `𝓖★TrU(D)`                  Legitimidad del transductor por especialización tipada.                                       [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L6_transductores/runner.py "null")
  Canal y diccionario        L.7. `Diag_AB^⊥`                         Consolidación sólo con canal, diccionario, retorno y residual.                                [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L7_canal_diccionario_diag/runner.py "null")
  Predominancia              L.8. Compatible y lesiva                 Distinción estructural entre asimetría gobernada y captura lesiva.                            [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L8_predominancia/runner.py "null")
  Matriz integrada           L.9. Integración completa                Integración sin tiempo rector, sintiencia, transmisión al unísono ni probabilidad fundante.   [runner.py](https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/laboratorios/L9_matriz_integrada/runner.py "null")

## **XVI. Conclusión** {#xvi-conclusin}

Aquí se establece el autogobierno topológico y la comunicación
estructural de observables en el Universo físico realizado como
continuación formal del potencial del suceso. El plano local de `P_D(e)`
permite leer separación polar, diferencia entre sucesos, residual, traza
y retorno; el plano global de `Φ(τ)` permite formalizar el comparador
con realimentación del dominio realizado bajo `ε−0`, convergencia
asintótica gobernada y conservación de `U` como indeterminación honesta.
La continuidad entre ambos planos no es identidad de objeto, sino
subordinación ordenada de niveles. El comparador con realimentación no
introduce agencia, voluntad, consciencia ni propósito. La comunicación
estructural no introduce diálogo sintiente ni transmisión física
coherente al unísono. La coherencia de los observables como conjunto se
formula como propiedad topológica del lazo bajo imperfección sostenida,
y su ejecución operativa se expresa mediante tránsito por dominios,
gobierno de observables, transductores, canal, diccionario semántico
estructural, residual, traza y retorno. La formulación mantiene las
prohibiciones constitutivas: sin tiempo rector, sin probabilidad como
criterio de verdad, sin heurística no declarada, sin inferencia opaca,
sin cierre favorable por ausencia de prueba y sin reducción de `U` a
ruido o desconocimiento informal. El resultado no cierra la arquitectura
técnica de célula, inventario y tablero matemático (u órgano total de
control), que queda como desarrollo posterior derivado; sí fija el nivel
superior de ensamblaje que conecta el potencial local del suceso con el
autogobierno topológico del dominio realizado y con la comunicación
estructural entre observables.

------------------------------------------------------------------------

## **Anexo I --- Bibliografía y referencias del corpus** {#anexo-i-bibliografa-y-referencias-del-corpus}

### **Fundamentos, principios y otros documentos del Sistema Vectorial SV**

-   Lloret Egea, J. A. (2026a). *Potencial de un suceso: comunicación
    estructural en el Universo físico realizado, equipotencialidad,
    diferencia polar y métrica*. IA eñ™ --- La Biblia de la IA™.
    <https://doi.org/10.21428/39829d0b.f0cbabc2>

-   Lloret Egea, J. A. (2026b). *Imperfección preformal y espacio: ε−0,
    primera distinguibilidad y dominio estructural completo de
    separación factual recorrible*. IA eñ™ --- La Biblia de la IA™.
    <https://doi.org/10.21428/39829d0b.9c57c046>

-   Lloret Egea, J. A. (2026c). *Teoría general de sucesos generadores y
    de los protocampos unificados en el Sistema Vectorial SV*. IA eñ™
    --- La Biblia de la IA™. <https://doi.org/10.17613/177nb-v2465>

-   Lloret Egea, J. A. (2026d). *Génesis del hidrógeno y teoría de la
    persistencia energética estructural: Masa, frontera, residual e
    identidad física bajo compatibilidad operatoria universal*. IA eñ™
    --- La Biblia de la IA™. <https://doi.org/10.17613/qq4q9-sd847>

-   Lloret Egea, J. A. (2026e). *Catálogo de Pares Estructurales SV
    (CPS-SV): Enlace, aleación y compatibilidad posicional desde los 118
    elementos base hasta los 443 candidatos del dominio extendido*. IA
    eñ™ --- La Biblia de la IA™.
    <https://doi.org/10.21428/39829d0b.a56b9cd7>

-   Lloret Egea, J. A. (2026f). *Teoría del TODO y de la NADA en el
    Sistema Vectorial SV*. IA eñ™ --- La Biblia de la IA™.
    <https://doi.org/10.17613/k3q1d-fjj45>

-   Lloret Egea, J. A. (2026g). *Primitivos metrológicos del Sistema
    Vectorial SV: Instanciaciones contingentes de las constantes
    fundacionales del Sistema Internacional, justificación algebraica y
    tabla de equivalencias factuales*. IA eñ™ --- La Biblia de la IA™.
    <https://doi.org/10.21428/39829d0b.c8ec692e>

-   Lloret Egea, J. A. (2026h). *Teorema de resolución física de la
    constante cosmológica: transducción ciclo-distancial SV de Λ,
    energía oscura y expansión cosmológica*. ITVIA --- IA eñ™ --- La
    Biblia de la IA™. <https://doi.org/10.21428/39829d0b.41afec0f>

-   Lloret Egea, J. A. (2026i). *Edades relativas del universo
    observable y de sus objetos físicos*. IA eñ™ --- La Biblia de la
    IA™. <https://doi.org/10.21428/39829d0b.b56ed853>

-   Lloret Egea, J. A. (2026j). *La materia oscura no existe como
    sustancia: Demostración formal de nulidad sustancial, densidad
    gravitatoria efectiva de sutura y contraste físico escalable*. IA
    eñ™ --- La Biblia de la IA™.
    <https://doi.org/10.21428/39829d0b.7b41835f>

-   Lloret Egea, J. A. (2026k). *El origen material ordinario del
    Universo observable y la relación entre física contemporánea y el SV
    en el tránsito por dominios: errores de plano, contraste entre
    aparatos y continuidad H--He de la materia ordinaria*. ITVIA --- IA
    eñ™ --- La Biblia de la IA™.
    <https://doi.org/10.21428/39829d0b.90fce13d>

-   Lloret Egea, J. A. (2026l). *Proyecciones biológicas de la fibra*.
    IA eñ™ --- La Biblia de la IA™.
    <https://doi.org/10.21428/39829d0b.1ab33893>

-   Lloret Egea, J. A. (2026m). *Agujero negro como cierre interno sin
    resto exterior formulable bajo el Sistema Vectorial SV*. IA eñ™ ---
    La Biblia de la IA™. <https://doi.org/10.21428/39829d0b.b757ccc4>

-   Lloret Egea, J. A. (2026n). *Autogobierno y comunicación estructural
    del Universo físico* \[Colección\]. ITVIA --- IA eñ™ --- La Biblia
    de la IA™. <https://doi.org/10.21428/39829d0b.552f4cfc>

-   Lloret Egea, J. A. (2026o). *El Universo* \[Colección\]. IA eñ™ ---
    La Biblia de la IA™. <https://doi.org/10.21428/39829d0b.26484bfd>

### **Referencias externas**

-   Aspect, A., Dalibard, J., y Roger, G. (1982). Experimental test of
    Bell\'s inequalities using time-varying analyzers. *Physical Review
    Letters*, *49*(25), 1804--1807.
    <https://doi.org/10.1103/PhysRevLett.49.1804>

-   Bekenstein, J. D. (1973). Black holes and entropy. *Physical Review
    D*, *7*(8), 2333--2346. <https://doi.org/10.1103/PhysRevD.7.2333>

-   Beyer, A., Maisenbacher, L., Matveev, A., Pohl, R., Khabarova, K.,
    Grinin, A., Lamour, T., Yost, D. C., Hänsch, T. W., Kolachevsky, N.,
    y Udem, T. (2017). The Rydberg constant and proton size from atomic
    hydrogen. *Science*, *358*(6359), 79--85.
    <https://doi.org/10.1126/science.aah6677>

-   Bilaniuk, O.-M. P., Deshpande, V. K., y Sudarshan, E. C. G. (1962).
    "Meta" relativity. *American Journal of Physics*, *30*(10),
    718--723.

-   Bohm, D. (1980). *Wholeness and the implicate order*. Routledge.

-   Boltzmann, L. (1872). Weitere Studien über das Wärmegleichgewicht
    unter Gasmolekülen. *Sitzungsberichte der Kaiserlichen Akademie der
    Wissenschaften*, *66*, 275--370.

-   Clausius, R. (1879). *The mechanical theory of heat*. Macmillan.

-   Clowe, D., Bradač, M., Gonzalez, A. H., Markevitch, M., Randall, S.
    W., Jones, C., y Zaritsky, D. (2006). A direct empirical proof of
    the existence of dark matter. *The Astrophysical Journal*, *648*(2),
    L109--L113. <https://doi.org/10.1086/508162>

-   Codd, E. F. (1979). Extending the database relational model to
    capture more meaning. *ACM Transactions on Database Systems*,
    *4*(4), 397--434. <https://doi.org/10.1145/320107.320109>

-   Cyburt, R. H., Fields, B. D., Olive, K. A., y Yeh, T.-H. (2016). Big
    bang nucleosynthesis: Present status. *Reviews of Modern Physics*,
    *88*(1), 015004. <https://doi.org/10.1103/RevModPhys.88.015004>

-   Eberhard, P. H. (1989). A realistic model for quantum theory with a
    locality property. En W. Schommers (Ed.), *Quantum Theory and
    Pictures of Reality* (pp. 169--215). Springer.
    <https://doi.org/10.1007/BF02728310>

-   Einstein, A. (1905). Zur Elektrodynamik bewegter Körper. *Annalen
    der Physik*, *17*(10), 891--921.
    <https://doi.org/10.1002/andp.19053221004>

-   Englert, F., y Brout, R. (1964). Broken symmetry and the mass of
    gauge vector mesons. *Physical Review Letters*, *13*(9), 321--323.
    <https://doi.org/10.1103/PhysRevLett.13.321>

-   Feinberg, G. (1967). Possibility of faster-than-light particles.
    *Physical Review*, *159*(5), 1089--1105.
    <https://doi.org/10.1103/PhysRev.159.1089>

-   Ghirardi, G. C., Rimini, A., y Weber, T. (1980). A general argument
    against superluminal transmission through the quantum mechanical
    measurement process. *Lettere al Nuovo Cimento*, *27*(10), 293--298.

-   Giustina, M., Versteegh, M. A. M., Wengerowsky, S., Handsteiner, J.,
    Hochrainer, A., Phelan, K., Steinlechner, F., Kofler, J., Larsson,
    J.-Å., Abellán, C., Amaya, W., Pruneri, V., Mitchell, M. W., Beyer,
    J., Gerrits, T., Lita, A. E., Shalm, L. K., Nam, S. W., Scheidl, T.,
    \... Zeilinger, A. (2015). Significant-loophole-free test of Bell\'s
    theorem with entangled photons. *Physical Review Letters*,
    *115*(25), 250401. <https://doi.org/10.1103/PhysRevLett.115.250401>

-   Goff, P. (2019). *Galileo\'s error: Foundations for a new science of
    consciousness*. Pantheon.

-   Hamming, R. W. (1980). The unreasonable effectiveness of
    mathematics. *The American Mathematical Monthly*, *87*(2), 81--90.
    <https://doi.org/10.2307/2321982>

-   Hellman, G. (1989). *Mathematics without numbers: Towards a
    modal-structural interpretation*. Oxford University Press.

-   Hensen, B., Bernien, H., Dréau, A. E., Reiserer, A., Kalb, N.,
    Blok, M. S., Ruitenberg, J., Vermeulen, R. F. L., Schouten, R. N.,
    Abellán, C., Amaya, W., Pruneri, V., Mitchell, M. W., Markham, M.,
    Twitchen, D. J., Elkouss, D., Wehner, S., Taminiau, T. H., y
    Hanson, R. (2015). Loophole-free Bell inequality violation using
    electron spins separated by 1.3 kilometres. *Nature*, *526*(7575),
    682--686. <https://doi.org/10.1038/nature15759>

-   Higgs, P. W. (1964). Broken symmetries and the masses of gauge
    bosons. *Physical Review Letters*, *13*(16), 508--509.
    <https://doi.org/10.1103/PhysRevLett.13.508>

-   Holevo, A. S. (1998). The capacity of the quantum channel with
    general signal states. *IEEE Transactions on Information Theory*,
    *44*(1), 269--273. <https://doi.org/10.1109/18.651037>

-   't Hooft, G. (1993). Dimensional reduction in quantum gravity.
    *arXiv*. <https://arxiv.org/abs/gr-qc/9310026>

-   Kleene, S. C. (1938). On notation for ordinal numbers. *Journal of
    Symbolic Logic*, *3*(4), 150--155. <https://doi.org/10.2307/2267778>

-   Łukasiewicz, J. (1920). O logice trójwartościowej. *Ruch
    Filozoficzny*, *5*, 170--171.

-   Maldacena, J., y Susskind, L. (2013). Cool horizons for entangled
    black holes. *Fortschritte der Physik*, *61*(9), 781--811.
    <https://doi.org/10.1002/prop.201300020>

-   Nicolis, G., y Prigogine, I. (1989). *Exploring complexity: An
    introduction*. W. H. Freeman. <https://doi.org/10.1063/1.2810937>

-   Nielsen, M. A., y Chuang, I. L. (2000). *Quantum computation and
    quantum information*. Cambridge University Press.

-   Penrose, R. (2010). *Cycles of time: An extraordinary new view of
    the universe*. The Bodley Head.

-   Planck Collaboration. (2020). Planck 2018 results. VI. Cosmological
    parameters. *Astronomy & Astrophysics*, *641*, A6.
    <https://doi.org/10.1051/0004-6361/201833910>

-   Prigogine, I., y Stengers, I. (1984). *Order out of chaos: Man\'s
    new dialogue with nature*. Bantam Books.

-   Resnik, M. D. (1997). *Mathematics as a science of patterns*. Oxford
    University Press.

-   Shannon, C. E. (1948). A mathematical theory of communication. *The
    Bell System Technical Journal*, *27*(3), 379--423.
    <https://doi.org/10.1002/j.1538-7305.1948.tb01338.x>

-   Shapiro, S. (1997). *Philosophy of mathematics: Structure and
    ontology*. Oxford University Press.

-   Smolin, L. (2013). *Time reborn: From the crisis in physics to the
    future of the universe*. Houghton Mifflin Harcourt.

-   Susskind, L. (1995). The world as a hologram. *Journal of
    Mathematical Physics*, *36*(11), 6377--6396.
    <https://doi.org/10.1063/1.531249>

-   Tegmark, M. (2008). The mathematical universe. *Foundations of
    Physics*, *38*(2), 101--150.
    <https://doi.org/10.1007/s10701-007-9186-9>

-   Wheeler, J. A. (1990). Information, physics, quantum: The search for
    links. En W. H. Zurek (Ed.), *Complexity, entropy and the physics of
    information* (pp. 3--28). Addison-Wesley.

-   Whitehead, A. N. (1929). *Process and reality*. Macmillan.

-   Wiener, N. (1948). *Cybernetics: Or control and communication in the
    animal and the machine*. MIT Press.

-   Wigner, E. P. (1960). The unreasonable effectiveness of mathematics
    in the natural sciences. *Communications on Pure and Applied
    Mathematics*, *13*(1), 1--14.
    <https://doi.org/10.1002/cpa.3160130102>

------------------------------------------------------------------------

**Advertencia.** Esta publicación está protegida por CEDRO y su
aplicación en el campo de la Física y la Química, así como cualquier
forma de explotación, reproducción o uso por parte de empresas, queda
sujeta al copyright del autor y a los términos de la licencia indicada;
la reproducción, distribución, comunicación pública o transformación de
esta obra solo puede ser realizada con la autorización de sus titulares,
salvo excepción prevista por la ley, y cualquier uso comercial sin
autorización expresa queda prohibido y sujeto estrictamente al
licenciamiento permitido.

***Warning.**** This publication is protected by CEDRO. Its application
in the field of Physics and Chemistry, as well as any form of
exploitation, reproduction, or use by corporate entities, is strictly
subject to the author\'s copyright and the terms of the license
indicated; any reproduction, distribution, public communication, or
transformation of this work requires authorization from the
rightsholders, except as provided by law, and any commercial use without
express written consent is prohibited and strictly subject to permitted
licensing.*

\| Url
canónica:<https://github.com/juantoniolloretegea/SV-matematica-semantica/blob/main/documentos/adendas/matematica-fisica-factual-contemporanea-sv/comunicacion-estructural-universo-fisico/autogobierno-topologico-comunicacion-estructural-observables/autogobierno-topologico-comunicacion-estructural-observables.md>
\|
